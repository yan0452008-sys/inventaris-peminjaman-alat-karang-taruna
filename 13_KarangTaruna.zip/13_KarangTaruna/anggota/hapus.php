<?php

session_start();

if (!isset($_SESSION['login'])) {
    header("Location: ../login.php");
    exit;
}

include "../koneksi.php";

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$id = $_GET['id'];

$query = mysqli_query(
    $conn,
    "DELETE FROM anggota WHERE id_anggota = '$id'"
);

header("Location: index.php");
exit;

?>
