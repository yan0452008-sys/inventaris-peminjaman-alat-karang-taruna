<?php

session_start();

if (!isset($_SESSION['login'])) {
    header("Location: ../login.php");
    exit;
}

include "../koneksi.php";

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$id = $_GET['id'];

$query = mysqli_query($conn, "
    SELECT * FROM anggota
    WHERE id_anggota = '$id'
");

$data = mysqli_fetch_assoc($query);

if (!$data) {
    echo "Data anggota tidak ditemukan.";
    exit;
}


if (isset($_POST['update'])) {

    $nama = mysqli_real_escape_string(
        $conn,
        $_POST['nama']
    );

    $jenis_kelamin = $_POST['jenis_kelamin'];

    $alamat = mysqli_real_escape_string(
        $conn,
        $_POST['alamat']
    );

    $no_hp = mysqli_real_escape_string(
        $conn,
        $_POST['no_hp']
    );

    $jabatan = mysqli_real_escape_string(
        $conn,
        $_POST['jabatan']
    );


    $update = mysqli_query($conn, "
        UPDATE anggota SET

            nama = '$nama',

            jenis_kelamin = '$jenis_kelamin',

            alamat = '$alamat',

            no_hp = '$no_hp',

            jabatan = '$jabatan'

        WHERE id_anggota = '$id'
    ");


    if ($update) {

        header("Location: index.php");
        exit;

    } else {

        $error = "Data gagal diperbarui.";

    }

}

?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Edit Anggota | Karang Taruna</title>

<style>

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
    font-family: "Segoe UI", Arial, sans-serif;
}

body {
    background: #f1f5f9;
    color: #1e293b;
}

.container {
    max-width: 800px;
    margin: 50px auto;
    padding: 20px;
}

.header {
    margin-bottom: 20px;
}

.header h1 {
    font-size: 25px;
    color: #0f172a;
}

.header p {
    color: #64748b;
    font-size: 13px;
    margin-top: 5px;
}

.card {
    background: white;
    border-radius: 16px;
    padding: 30px;
    border: 1px solid #e2e8f0;
    box-shadow: 0 10px 30px rgba(15,23,42,0.05);
}

.form-group {
    margin-bottom: 20px;
}

label {
    display: block;
    font-size: 13px;
    font-weight: 600;
    margin-bottom: 8px;
    color: #334155;
}

input,
select,
textarea {
    width: 100%;
    padding: 12px 14px;
    border: 1px solid #cbd5e1;
    border-radius: 9px;
    outline: none;
    font-size: 14px;
}

input:focus,
select:focus,
textarea:focus {
    border-color: #2563eb;
    box-shadow: 0 0 0 3px rgba(37,99,235,0.1);
}

textarea {
    min-height: 100px;
    resize: vertical;
}

.error {
    background: #fee2e2;
    color: #b91c1c;
    padding: 12px;
    border-radius: 8px;
    margin-bottom: 20px;
}

.button-group {
    display: flex;
    gap: 10px;
    margin-top: 25px;
}

.btn {
    padding: 12px 20px;
    border-radius: 9px;
    text-decoration: none;
    border: none;
    cursor: pointer;
    font-size: 13px;
}

.btn-update {
    background: linear-gradient(
        135deg,
        #2563eb,
        #4f46e5
    );

    color: white;
}

.btn-kembali {
    background: #e2e8f0;
    color: #334155;
}

</style>

</head>

<body>

<div class="container">

    <div class="header">

        <h1>
            ✏️ Edit Anggota
        </h1>

        <p>
            Perbarui data anggota Karang Taruna
        </p>

    </div>


    <div class="card">

        <?php if (isset($error)): ?>

            <div class="error">
                <?php echo $error; ?>
            </div>

        <?php endif; ?>


        <form method="POST">


            <div class="form-group">

                <label>
                    Nama Lengkap
                </label>

                <input
                    type="text"
                    name="nama"
                    value="<?php echo htmlspecialchars($data['nama']); ?>"
                    required
                >

            </div>


            <div class="form-group">

                <label>
                    Jenis Kelamin
                </label>

                <select
                    name="jenis_kelamin"
                    required
                >

                    <option
                        value="Laki-laki"
                        <?php
                        if ($data['jenis_kelamin'] == 'Laki-laki')
                            echo 'selected';
                        ?>
                    >
                        Laki-laki
                    </option>

                    <option
                        value="Perempuan"
                        <?php
                        if ($data['jenis_kelamin'] == 'Perempuan')
                            echo 'selected';
                        ?>
                    >
                        Perempuan
                    </option>

                </select>

            </div>


            <div class="form-group">

                <label>
                    Nomor HP
                </label>

                <input
                    type="text"
                    name="no_hp"
                    value="<?php echo htmlspecialchars($data['no_hp']); ?>"
                >

            </div>


            <div class="form-group">

                <label>
                    Jabatan
                </label>

                <select name="jabatan">

                    <option
                        value="Anggota"
                        <?php
                        if ($data['jabatan'] == 'Anggota')
                            echo 'selected';
                        ?>
                    >
                        Anggota
                    </option>

                    <option
                        value="Ketua"
                        <?php
                        if ($data['jabatan'] == 'Ketua')
                            echo 'selected';
                        ?>
                    >
                        Ketua
                    </option>

                    <option
                        value="Wakil Ketua"
                        <?php
                        if ($data['jabatan'] == 'Wakil Ketua')
                            echo 'selected';
                        ?>
                    >
                        Wakil Ketua
                    </option>

                    <option
                        value="Sekretaris"
                        <?php
                        if ($data['jabatan'] == 'Sekretaris')
                            echo 'selected';
                        ?>
                    >
                        Sekretaris
                    </option>

                    <option
                        value="Bendahara"
                        <?php
                        if ($data['jabatan'] == 'Bendahara')
                            echo 'selected';
                        ?>
                    >
                        Bendahara
                    </option>

                </select>

            </div>


            <div class="form-group">

                <label>
                    Alamat
                </label>

                <textarea
                    name="alamat"
                ><?php echo htmlspecialchars($data['alamat']); ?></textarea>

            </div>


            <div class="button-group">

                <a
                    href="index.php"
                    class="btn btn-kembali"
                >
                    ← Kembali
                </a>

                <button
                    type="submit"
                    name="update"
                    class="btn btn-update"
                >
                    💾 Simpan Perubahan
                </button>

            </div>


        </form>

    </div>

</div>

</body>

</html>
