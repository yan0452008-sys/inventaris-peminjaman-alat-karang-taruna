<?php
session_start();
include "koneksi.php";

$error = "";
$sukses = "";

if (isset($_SESSION['login']) && $_SESSION['login'] === true) {
    if (($_SESSION['role'] ?? '') === 'admin') {
        header("Location: dashboard.php");
    } elseif (($_SESSION['role'] ?? '') === 'anggota') {
        header("Location: user/dashboard.php");
    } else {
        session_unset();
        session_destroy();
        header("Location: login.php");
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $konfirmasi = $_POST['konfirmasi'] ?? '';

    if ($username === '' || $password === '' || $konfirmasi === '') {
        $error = "Semua kolom wajib diisi!";
    } elseif (!preg_match('/^[a-zA-Z0-9_.-]{4,50}$/', $username)) {
        $error = "Username harus 4–50 karakter dan hanya boleh berisi huruf, angka, titik, garis bawah, atau tanda hubung.";
    } elseif (strlen($password) < 8) {
        $error = "Password minimal 8 karakter!";
    } elseif ($password !== $konfirmasi) {
        $error = "Konfirmasi password tidak cocok!";
    } else {
        $stmt = mysqli_prepare(
            $conn,
            "SELECT id_user FROM users WHERE username = ? LIMIT 1"
        );

        if (!$stmt) {
            $error = "Terjadi kesalahan saat memeriksa username.";
        } else {
            mysqli_stmt_bind_param($stmt, "s", $username);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_store_result($stmt);

            $usernameAda = mysqli_stmt_num_rows($stmt) > 0;
            mysqli_stmt_close($stmt);

            if ($usernameAda) {
                $error = "Username sudah digunakan. Silakan pilih username lain.";
            } else {
                $hashPassword = password_hash($password, PASSWORD_DEFAULT);

                $stmt = mysqli_prepare(
                    $conn,
                    "INSERT INTO users (username, password, role)
                     VALUES (?, ?, 'anggota')"
                );

                if ($stmt) {
                    mysqli_stmt_bind_param(
                        $stmt,
                        "ss",
                        $username,
                        $hashPassword
                    );

                    if (mysqli_stmt_execute($stmt)) {
                        $sukses = "Pendaftaran berhasil! Silakan login menggunakan akun Warga.";
                    } else {
                        $error = "Pendaftaran gagal. Silakan coba kembali.";
                    }

                    mysqli_stmt_close($stmt);
                } else {
                    $error = "Terjadi kesalahan saat membuat akun.";
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Warga | Karang Taruna</title>

    <style>
        * {
            box-sizing: border-box;
            font-family: "Segoe UI", Arial, sans-serif;
        }

        body {
            margin: 0;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 24px;
            background: linear-gradient(135deg, #0f172a, #1e3a8a, #312e81);
        }

        .card {
            width: 100%;
            max-width: 440px;
            background: #fff;
            padding: 35px;
            border-radius: 20px;
            box-shadow: 0 20px 50px rgba(0, 0, 0, .25);
        }

        h1 {
            margin: 0 0 8px;
            color: #0f172a;
            font-size: 27px;
        }

        .subtitle {
            color: #64748b;
            margin-bottom: 25px;
            line-height: 1.6;
            font-size: 14px;
        }

        label {
            display: block;
            margin-bottom: 7px;
            font-size: 14px;
            font-weight: 600;
            color: #334155;
        }

        input {
            width: 100%;
            padding: 13px;
            margin-bottom: 18px;
            border: 1px solid #cbd5e1;
            border-radius: 10px;
            outline: none;
            font-size: 14px;
        }

        input:focus {
            border-color: #2563eb;
            box-shadow: 0 0 0 3px rgba(37, 99, 235, .12);
        }

        button {
            width: 100%;
            padding: 14px;
            border: 0;
            border-radius: 10px;
            color: white;
            background: linear-gradient(135deg, #2563eb, #4f46e5);
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
        }

        .pesan {
            padding: 12px;
            border-radius: 9px;
            margin-bottom: 18px;
            font-size: 14px;
            line-height: 1.5;
        }

        .error {
            color: #b91c1c;
            background: #fee2e2;
        }

        .sukses {
            color: #166534;
            background: #dcfce7;
        }

        .link {
            text-align: center;
            margin-top: 22px;
            color: #64748b;
            font-size: 14px;
        }

        a {
            color: #2563eb;
            text-decoration: none;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="card">
        <h1>Daftar Akun Warga</h1>
        <p class="subtitle">
            Buat akun untuk mengakses layanan peminjaman alat
            Karang Taruna Manunggal Bhakti.
        </p>

        <?php if ($error !== ''): ?>
            <div class="pesan error" role="alert">
                <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <?php if ($sukses !== ''): ?>
            <div class="pesan sukses" role="status">
                <?= htmlspecialchars($sukses, ENT_QUOTES, 'UTF-8') ?>
                <br><br>
                <a href="login.php">Lanjut ke halaman login</a>
            </div>
        <?php else: ?>
            <form method="POST" action="">
                <label for="username">Username</label>
                <input
                    type="text"
                    id="username"
                    name="username"
                    minlength="4"
                    maxlength="50"
                    pattern="[a-zA-Z0-9_.-]{4,50}"
                    autocomplete="username"
                    placeholder="Buat username"
                    required
                >

                <label for="password">Password</label>
                <input
                    type="password"
                    id="password"
                    name="password"
                    minlength="8"
                    autocomplete="new-password"
                    placeholder="Minimal 8 karakter"
                    required
                >

                <label for="konfirmasi">Konfirmasi Password</label>
                <input
                    type="password"
                    id="konfirmasi"
                    name="konfirmasi"
                    minlength="8"
                    autocomplete="new-password"
                    placeholder="Ulangi password"
                    required
                >

                <button type="submit">Daftar Sekarang</button>
            </form>
        <?php endif; ?>

        <div class="link">
            Sudah punya akun? <a href="login.php">Login di sini</a>
        </div>
    </div>
</body>
</html>
