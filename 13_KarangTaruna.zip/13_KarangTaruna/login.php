<?php
session_start();

include "koneksi.php";

$error = "";

// Jika pengguna sudah login, arahkan sesuai role
if (isset($_SESSION['login']) && $_SESSION['login'] === true) {

    if ($_SESSION['role'] === 'admin') {
        header("Location: dashboard.php");
    } elseif ($_SESSION['role'] === 'anggota') {
        header("Location: user/dashboard.php");
    } else {
        session_unset();
        session_destroy();
        header("Location: login.php");
    }

    exit;
}

// Proses login
if (isset($_POST['login'])) {

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {

        $error = "Username dan password wajib diisi!";

    } else {

        // Mencari akun berdasarkan username
        $stmt = mysqli_prepare(
            $conn,
            "SELECT id_user, username, password, role
             FROM users
             WHERE username = ?
             LIMIT 1"
        );

        if ($stmt) {

            mysqli_stmt_bind_param($stmt, "s", $username);
            mysqli_stmt_execute($stmt);

            $result = mysqli_stmt_get_result($stmt);
            $data = mysqli_fetch_assoc($result);

            /*
             * Mendukung password_hash() dan password lama
             * yang masih disimpan sebagai teks biasa.
             *
             * Password teks biasa sebaiknya dimigrasikan
             * ke password_hash() untuk keamanan.
             */
            $passwordValid = false;

            if ($data) {

                $hashInfo = password_get_info($data['password']);

                if ($hashInfo['algo'] !== null &&
                    $hashInfo['algo'] !== false) {

                    $passwordValid = password_verify(
                        $password,
                        $data['password']
                    );

                } else {

                    // Kompatibilitas dengan password lama
                    $passwordValid = hash_equals(
                        (string) $data['password'],
                        (string) $password
                    );
                }
            }

            if ($data && $passwordValid) {

                if (
                    $data['role'] === 'admin' ||
                    $data['role'] === 'anggota'
                ) {

                    // Membuat session baru setelah login
                    session_regenerate_id(true);

                    $_SESSION['login'] = true;
                    $_SESSION['id_user'] = $data['id_user'];
                    $_SESSION['username'] = $data['username'];
                    $_SESSION['role'] = $data['role'];

                    mysqli_stmt_close($stmt);

                    // Arahkan sesuai hak akses
                    if ($data['role'] === 'admin') {
                        header("Location: dashboard.php");
                    } else {
                        header("Location: user/dashboard.php");
                    }

                    exit;

                } else {

                    $error = "Role akun tidak dikenali!";
                }

            } else {

                $error = "Username atau password salah!";
            }

            mysqli_stmt_close($stmt);

        } else {

            $error = "Terjadi kesalahan pada sistem login.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Login | Karang Taruna</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Segoe UI", Arial, sans-serif;
        }

        body {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;

            background:
                radial-gradient(
                    circle at top left,
                    #38bdf8 0%,
                    transparent 35%
                ),
                radial-gradient(
                    circle at bottom right,
                    #8b5cf6 0%,
                    transparent 35%
                ),
                linear-gradient(
                    135deg,
                    #0f172a,
                    #1e3a8a,
                    #312e81
                );

            overflow-x: hidden;
            position: relative;
            padding: 25px 0;
        }

        body::before {
            content: "";
            position: fixed;
            width: 350px;
            height: 350px;
            background: rgba(255,255,255,0.08);
            border-radius: 50%;
            top: -100px;
            left: -100px;
            filter: blur(2px);
            pointer-events: none;
        }

        body::after {
            content: "";
            position: fixed;
            width: 400px;
            height: 400px;
            background: rgba(255,255,255,0.06);
            border-radius: 50%;
            bottom: -150px;
            right: -100px;
            pointer-events: none;
        }

        .login-container {
            width: 900px;
            max-width: 92%;
            min-height: 540px;

            display: grid;
            grid-template-columns: 1fr 1fr;

            background: rgba(255,255,255,0.12);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);

            border: 1px solid rgba(255,255,255,0.2);
            border-radius: 25px;
            overflow: hidden;

            box-shadow: 0 30px 80px rgba(0,0,0,0.35);

            position: relative;
            z-index: 2;
        }

        /* Bagian kiri */

        .left {
            padding: 55px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            color: white;

            background:
                linear-gradient(
                    145deg,
                    rgba(37,99,235,0.75),
                    rgba(79,70,229,0.55)
                );
        }

        .logo {
            width: 85px;
            height: 85px;

            background: rgba(255,255,255,0.15);
            border: 1px solid rgba(255,255,255,0.3);
            border-radius: 22px;

            display: flex;
            justify-content: center;
            align-items: center;

            font-size: 42px;
            margin-bottom: 30px;

            box-shadow: 0 15px 30px rgba(0,0,0,0.15);
        }

        .left h1 {
            font-size: 38px;
            line-height: 1.15;
            margin-bottom: 18px;
        }

        .left h1 span {
            color: #7dd3fc;
        }

        .left p {
            font-size: 16px;
            line-height: 1.8;
            color: rgba(255,255,255,0.8);
            max-width: 400px;
        }

        .features {
            margin-top: 30px;
        }

        .feature {
            display: flex;
            align-items: center;
            gap: 12px;
            margin: 13px 0;
            color: rgba(255,255,255,0.9);
            font-size: 14px;
        }

        .check {
            width: 25px;
            height: 25px;
            flex-shrink: 0;

            display: flex;
            align-items: center;
            justify-content: center;

            border-radius: 50%;
            background: rgba(255,255,255,0.15);
            color: #7dd3fc;
        }

        /* Bagian kanan */

        .right {
            background: rgba(255,255,255,0.95);
            padding: 55px;

            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .right h2 {
            color: #0f172a;
            font-size: 30px;
            margin-bottom: 8px;
        }

        .subtitle {
            color: #64748b;
            margin-bottom: 30px;
            font-size: 14px;
            line-height: 1.6;
        }

        /* Pesan kesalahan */

        .error {
            background: #fee2e2;
            border: 1px solid #fecaca;
            color: #b91c1c;

            padding: 12px 15px;
            border-radius: 10px;
            margin-bottom: 20px;

            font-size: 14px;
            line-height: 1.6;
        }

        /* Form login */

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #334155;
            font-size: 14px;
            font-weight: 600;
        }

        .input-box {
            position: relative;
        }

        .input-box span {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 18px;
            color: #64748b;
            pointer-events: none;
        }

        .input-box input {
            width: 100%;
            padding: 14px 15px 14px 45px;

            border: 1px solid #e2e8f0;
            border-radius: 12px;
            outline: none;

            font-size: 14px;
            transition: 0.3s;
            background: #f8fafc;
        }

        .input-box input:focus {
            border-color: #3b82f6;
            background: white;
            box-shadow: 0 0 0 4px rgba(59,130,246,0.1);
        }

        /* Tombol login */

        .btn-login {
            width: 100%;
            padding: 15px;

            border: none;
            border-radius: 12px;

            background: linear-gradient(
                135deg,
                #2563eb,
                #4f46e5
            );

            color: white;
            font-size: 15px;
            font-weight: 600;

            cursor: pointer;
            transition: 0.3s;

            box-shadow: 0 10px 20px rgba(37,99,235,0.25);
        }

        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 15px 30px rgba(37,99,235,0.35);
        }

        .btn-login:active {
            transform: translateY(0);
        }

        .footer {
            text-align: center;
            margin-top: 25px;
            color: #94a3b8;
            font-size: 12px;
        }

        /* Tampilan HP */

        @media (max-width: 750px) {
            .login-container {
                grid-template-columns: 1fr;
                min-height: auto;
            }

            .left {
                padding: 35px 25px;
                text-align: center;
                align-items: center;
            }

            .left h1 {
                font-size: 30px;
            }

            .left p {
                font-size: 14px;
            }

            .features {
                display: none;
            }

            .right {
                padding: 35px 25px;
            }

            .right h2 {
                font-size: 26px;
            }
        }
    </style>
</head>

<body>

<div class="login-container">

    <!-- BAGIAN KIRI -->

    <div class="left">

        <div class="logo">🏘️</div>

        <h1>
            Karang Taruna Manunggal Bhakti<br>
            <span>Digital</span>
        </h1>

        <p>
            Sistem informasi untuk mengelola data anggota,
            inventaris, serta peminjaman alat Karang Taruna
            secara lebih mudah dan terorganisir.
        </p>

        <div class="features">

            <div class="feature">
                <div class="check">✓</div>
                Pendataan anggota
            </div>

            <div class="feature">
                <div class="check">✓</div>
                Pengelolaan inventaris
            </div>

            <div class="feature">
                <div class="check">✓</div>
                Peminjaman dan pengembalian
            </div>

            <div class="feature">
                <div class="check">✓</div>
                Laporan kegiatan
            </div>

        </div>

    </div>

    <!-- BAGIAN KANAN -->

    <div class="right">

        <h2>Selamat Datang 👋</h2>

        <div class="subtitle">
            Silakan masuk menggunakan akun Admin atau Anggota.
        </div>

        <?php if ($error !== ""): ?>

            <div class="error" role="alert">
                <?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?>
            </div>

        <?php endif; ?>

        <form method="POST" action="">

            <div class="form-group">

                <label for="username">Username</label>

                <div class="input-box">

                    <span>👤</span>

                    <input
                        type="text"
                        id="username"
                        name="username"
                        placeholder="Masukkan username"
                        autocomplete="username"
                        maxlength="50"
                        required
                    >

                </div>

            </div>

            <div class="form-group">

                <label for="password">Password</label>

                <div class="input-box">

                    <span>🔒</span>

                    <input
                        type="password"
                        id="password"
                        name="password"
                        placeholder="Masukkan password"
                        autocomplete="current-password"
                        required
                    >

                </div>

            </div>

            <button
                type="submit"
                name="login"
                class="btn-login"
            >
                Masuk ke Sistem →
            </button>

        </form>

        <div class="footer">
            © 2026 Sistem Informasi Karang Taruna
        </div>

    </div>

</div>

</body>
</html>