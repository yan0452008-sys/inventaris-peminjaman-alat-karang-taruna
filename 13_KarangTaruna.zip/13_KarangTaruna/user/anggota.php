
<?php
session_start();

if (
    !isset($_SESSION['login']) ||
    $_SESSION['login'] !== true ||
    !isset($_SESSION['role']) ||
    $_SESSION['role'] !== 'anggota'
) {
    header("Location: ../login.php");
    exit;
}

include "../koneksi.php";

$query = mysqli_query(
    $conn,
    "SELECT * FROM anggota ORDER BY id_anggota DESC"
);

if (!$query) {
    die("Gagal mengambil data anggota.");
}

function e($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Anggota - Karang Taruna</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            color: #1e293b;
        }

        .sidebar {
            width: 250px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            padding: 25px 18px;
            background: linear-gradient(180deg, #1e3a8a, #312e81);
            color: white;
        }

        .logo {
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .subtitle {
            font-size: 12px;
            color: #cbd5e1;
            margin-bottom: 30px;
        }

        .menu {
            display: block;
            padding: 13px 15px;
            margin-bottom: 8px;
            border-radius: 9px;
            color: white;
            text-decoration: none;
            font-size: 14px;
        }

        .menu:hover,
        .menu.active {
            background: rgba(255, 255, 255, 0.18);
        }

        .logout {
            margin-top: 25px;
            background: rgba(239, 68, 68, 0.2);
        }

        .main {
            margin-left: 250px;
            padding: 30px;
        }

        .header {
            margin-bottom: 25px;
        }

        .header h1 {
            margin: 0 0 8px;
            font-size: 27px;
        }

        .header p {
            margin: 0;
            color: #64748b;
        }

        .card {
            background: white;
            padding: 24px;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(15, 23, 42, 0.05);
        }

        .tools {
            display: flex;
            justify-content: space-between;
            gap: 15px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .search {
            width: 300px;
            max-width: 100%;
            padding: 11px 14px;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            font-size: 14px;
        }

        .table-wrapper {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 650px;
        }

        th, td {
            padding: 14px 12px;
            border-bottom: 1px solid #e2e8f0;
            text-align: left;
            font-size: 14px;
        }

        th {
            background: #f8fafc;
            color: #475569;
        }

        tbody tr:hover {
            background: #f8fafc;
        }

        .empty {
            text-align: center;
            color: #64748b;
            padding: 25px;
        }

        @media (max-width: 800px) {
            .sidebar {
                width: 70px;
                padding: 20px 8px;
            }

            .logo {
                font-size: 12px;
                overflow-wrap: anywhere;
            }

            .subtitle {
                display: none;
            }

            .menu {
                padding: 12px 5px;
                font-size: 10px;
                text-align: center;
                overflow-wrap: anywhere;
            }

            .main {
                margin-left: 70px;
                padding: 18px 12px;
            }

            .card {
                padding: 15px;
            }
        }
    </style>
</head>

<body>

<aside class="sidebar">
    <div class="logo">Karang Taruna</div>
    <div class="subtitle">Sistem Informasi</div>

    <a class="menu" href="dashboard.php">Dashboard</a>
    <a class="menu active" href="anggota.php">Data Anggota</a>
    <a class="menu" href="alat.php">Lihat Data Alat</a>
    <a class="menu" href="ajukan_peminjaman.php">Ajukan Peminjaman</a>
    <a class="menu" href="peminjaman.php">Status Peminjaman</a>
    <a class="menu logout" href="logout.php">Logout</a>
</aside>

<main class="main">
    <div class="header">
        <h1>Data Anggota</h1>
        <p>Informasi anggota Karang Taruna Manunggal Bhakti.</p>
    </div>

    <section class="card">
        <div class="tools">
            <input
                type="text"
                id="search"
                class="search"
                placeholder="Cari nama, jabatan, atau alamat..."
            >
        </div>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Anggota</th>
                        <th>Jenis Kelamin</th>
                        <th>Alamat</th>
                        <th>Nomor HP</th>
                        <th>Jabatan</th>
                    </tr>
                </thead>

                <tbody id="tableBody">
                    <?php
                    $no = 1;

                    if (mysqli_num_rows($query) > 0):
                        while ($row = mysqli_fetch_assoc($query)):
                    ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= e($row['nama']) ?></td>
                        <td><?= e($row['jenis_kelamin']) ?></td>
                        <td><?= e($row['alamat']) ?></td>
                        <td><?= e($row['nomor_hp'] ?? $row['no_hp'] ?? $row['no_telp'] ?? '-') ?></td>
                        <td><?= e($row['jabatan']) ?></td>
                    </tr>
                    <?php
                        endwhile;
                    else:
                    ?>
                    <tr>
                        <td colspan="6" class="empty">
                            Belum ada data anggota.
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</main>

<script>
document.getElementById("search").addEventListener("input", function () {
    const keyword = this.value.toLowerCase();

    document.querySelectorAll("#tableBody tr").forEach(function (row) {
        row.style.display = row.textContent.toLowerCase().includes(keyword)
            ? ""
            : "none";
    });
});
</script>

</body>
</html>
