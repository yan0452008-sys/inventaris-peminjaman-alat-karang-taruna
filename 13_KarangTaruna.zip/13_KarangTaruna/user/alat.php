
<?php
session_start();

if (
    !isset($_SESSION['login']) ||
    !isset($_SESSION['role']) ||
    $_SESSION['role'] !== 'anggota'
) {
    header("Location: ../login.php");
    exit;
}

include "../koneksi.php";

$query = mysqli_query($conn, "
    SELECT id_alat, nama_alat, kategori, jumlah, kondisi, lokasi
    FROM alat
    ORDER BY id_alat DESC
");

if (!$query) {
    die("Gagal mengambil data alat.");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Alat - Karang Taruna</title>
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 25px;
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            color: #1e293b;
        }

        .container {
            max-width: 1100px;
            margin: auto;
        }

        .header {
            background: linear-gradient(135deg, #1e3a8a, #4f46e5);
            color: white;
            padding: 25px;
            border-radius: 15px;
            margin-bottom: 22px;
        }

        .header h2 {
            margin: 0 0 8px;
        }

        .header p {
            margin: 0;
        }

        .back {
            display: inline-block;
            margin-bottom: 18px;
            color: #1d4ed8;
            text-decoration: none;
            font-weight: bold;
        }

        .card {
            background: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 4px 15px #0f172a0d;
            overflow-x: auto;
        }

        input {
            width: 100%;
            max-width: 350px;
            padding: 11px;
            margin-bottom: 18px;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 650px;
        }

        th, td {
            padding: 13px;
            border-bottom: 1px solid #e2e8f0;
            text-align: left;
        }

        th {
            background: #eff6ff;
            color: #1e40af;
        }

        tr:hover {
            background: #f8fafc;
        }

        .empty {
            text-align: center;
            color: #64748b;
        }
    </style>
</head>
<body>
<div class="container">
    <a class="back" href="dashboard.php">&larr; Kembali ke Dashboard</a>

    <div class="header">
        <h2>Data Alat</h2>
        <p>Inventaris Karang Taruna Manunggal Bhakti Digital</p>
    </div>

    <div class="card">
        <h3>Daftar Inventaris</h3>

        <input
            type="text"
            id="search"
            placeholder="Cari nama alat, kategori, atau lokasi..."
        >

        <table>
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Nama Alat</th>
                    <th>Kategori</th>
                    <th>Jumlah</th>
                    <th>Kondisi</th>
                    <th>Lokasi</th>
                </tr>
            </thead>
            <tbody id="tableBody">
            <?php
            $no = 1;

            if (mysqli_num_rows($query) > 0):
                while ($alat = mysqli_fetch_assoc($query)):
            ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= htmlspecialchars($alat['nama_alat'] ?? '') ?></td>
                    <td><?= htmlspecialchars($alat['kategori'] ?? '') ?></td>
                    <td><?= (int) $alat['jumlah'] ?></td>
                    <td><?= htmlspecialchars($alat['kondisi'] ?? '') ?></td>
                    <td><?= htmlspecialchars($alat['lokasi'] ?? '') ?></td>
                </tr>
            <?php
                endwhile;
            else:
            ?>
                <tr>
                    <td colspan="6" class="empty">
                        Belum ada data alat.
                    </td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
document.getElementById('search').addEventListener('input', function () {
    const keyword = this.value.toLowerCase();

    document.querySelectorAll('#tableBody tr').forEach(function (row) {
        row.style.display = row.textContent.toLowerCase().includes(keyword)
            ? ''
            : 'none';
    });
});
</script>
</body>
</html>
