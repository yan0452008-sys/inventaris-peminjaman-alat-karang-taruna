
<?php
session_start();

if (
    !isset($_SESSION['login']) ||
    $_SESSION['login'] !== true ||
    !isset($_SESSION['role']) ||
    !in_array($_SESSION['role'], ['anggota', 'warga'], true)
) {
    header("Location: ../login.php");
    exit;
}

include "../koneksi.php";

$id_user = (int) ($_SESSION['id_user'] ?? 0);

if ($id_user <= 0) {
    die("ID akun tidak ditemukan. Silakan keluar dan login kembali.");
}

$pesan = "";
$nama_peminjam = trim($_POST['nama_peminjam'] ?? '');
$jenisPesan = "error";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_alat = (int) ($_POST['id_alat'] ?? 0);
    $jumlah = (int) ($_POST['jumlah_pinjam'] ?? 0);
    $tanggal_pinjam = trim($_POST['tanggal_pinjam'] ?? '');
    $tanggal_kembali = trim($_POST['tanggal_kembali'] ?? '');
    $keperluan = trim($_POST['keperluan'] ?? '');

    // Validasi tanggal
    $tglPinjam = DateTime::createFromFormat('!Y-m-d', $tanggal_pinjam);
    $tglKembali = DateTime::createFromFormat('!Y-m-d', $tanggal_kembali);

    $validTanggal =
        $tglPinjam !== false &&
        $tglPinjam->format('Y-m-d') === $tanggal_pinjam &&
        $tglKembali !== false &&
        $tglKembali->format('Y-m-d') === $tanggal_kembali;

    $tanggalHariIni = date('Y-m-d');

    if (
        $nama_peminjam === '' ||
        mb_strlen($nama_peminjam) > 100 ||
        $id_alat <= 0 ||
        $jumlah <= 0 ||
        !$validTanggal ||
        $tanggal_pinjam < $tanggalHariIni ||
        $tanggal_kembali < $tanggal_pinjam ||
        $keperluan === ''
    ) {
        $pesan = "Periksa kembali formulir. Nama wajib diisi (maksimal 100 karakter), jumlah harus lebih dari 0, dan tanggal harus valid.";
    } else {
        mysqli_begin_transaction($conn);

        try {
            // Periksa stok dan kondisi alat
            $stmtAlat = mysqli_prepare(
                $conn,
                "SELECT nama_alat, jumlah, kondisi
                 FROM alat
                 WHERE id_alat = ?
                 FOR UPDATE"
            );

            if (!$stmtAlat) {
                throw new Exception("Gagal memeriksa data alat.");
            }

            mysqli_stmt_bind_param($stmtAlat, "i", $id_alat);
            mysqli_stmt_execute($stmtAlat);

            $hasilAlat = mysqli_stmt_get_result($stmtAlat);
            $alat = mysqli_fetch_assoc($hasilAlat);

            mysqli_stmt_close($stmtAlat);

            if (!$alat) {
                throw new Exception("Alat tidak ditemukan.");
            }

            $kondisi = strtolower(trim($alat['kondisi'] ?? ''));

            if (in_array(
                $kondisi,
                ['rusak berat', 'rusak-berat', 'rusak_berat'],
                true
            )) {
                throw new Exception(
                    "Alat dalam kondisi rusak berat dan tidak dapat diajukan."
                );
            }

            $stok = (int) $alat['jumlah'];

            if ($stok <= 0) {
                throw new Exception("Stok alat sedang habis.");
            }

            if ($jumlah > $stok) {
                throw new Exception(
                    "Jumlah pinjaman melebihi stok alat yang tersedia."
                );
            }

            // Pengajuan baru berstatus Menunggu
            $status = 'Menunggu';

            $stmt = mysqli_prepare(
                $conn,
                "INSERT INTO peminjaman
                (
                    nama_peminjam,
                    id_alat,
                    jumlah_pinjam,
                    tanggal_pinjam,
                    tanggal_kembali,
                    keperluan,
                    status,
                    id_user
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
            );

            if (!$stmt) {
                throw new Exception("Gagal menyiapkan penyimpanan pengajuan.");
            }

            mysqli_stmt_bind_param(
                $stmt,
                "siissssi",
                $nama_peminjam,
                $id_alat,
                $jumlah,
                $tanggal_pinjam,
                $tanggal_kembali,
                $keperluan,
                $status,
                $id_user
            );

            if (!mysqli_stmt_execute($stmt)) {
                mysqli_stmt_close($stmt);
                throw new Exception("Pengajuan gagal disimpan.");
            }

            mysqli_stmt_close($stmt);
            mysqli_commit($conn);

            header("Location: peminjaman.php?pengajuan=berhasil");
            exit;

        } catch (Throwable $e) {
            mysqli_rollback($conn);
            $pesan = $e->getMessage();
        }
    }
}

// Ambil daftar alat
$queryAlat = mysqli_query(
    $conn,
    "SELECT id_alat, nama_alat, jumlah, kondisi
     FROM alat
     ORDER BY nama_alat ASC"
);

if (!$queryAlat) {
    die("Gagal mengambil data alat.");
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajukan Peminjaman</title>

    <style>
        * {
            box-sizing: border-box;
            font-family: "Segoe UI", Arial, sans-serif;
        }

        body {
            margin: 0;
            padding: 25px;
            background: #f1f5f9;
            color: #1e293b;
        }

        .container {
            max-width: 760px;
            margin: auto;
        }

        .back {
            display: inline-block;
            margin-bottom: 18px;
            color: #1d4ed8;
            text-decoration: none;
            font-weight: bold;
        }

        .header {
            padding: 25px;
            border-radius: 15px;
            color: white;
            background: linear-gradient(120deg, #2563eb, #4f46e5);
            margin-bottom: 22px;
        }

        .header h2 {
            margin: 0 0 8px;
        }

        .header p {
            margin: 0;
            color: #e0e7ff;
            line-height: 1.6;
        }

        .card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(15, 23, 42, .05);
        }

        .card h3 {
            margin-top: 0;
        }

        label {
            display: block;
            margin: 16px 0 7px;
            font-weight: 600;
            font-size: 14px;
        }

        input, select, textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            background: white;
            font-size: 14px;
            color: #1e293b;
        }

        input:focus, select:focus, textarea:focus {
            outline: none;
            border-color: #2563eb;
            box-shadow: 0 0 0 3px rgba(37, 99, 235, .12);
        }

        textarea {
            resize: vertical;
            min-height: 100px;
        }

        button {
            width: 100%;
            margin-top: 22px;
            padding: 13px;
            border: none;
            border-radius: 9px;
            color: white;
            font-weight: bold;
            font-size: 15px;
            background: linear-gradient(120deg, #2563eb, #4f46e5);
            cursor: pointer;
        }

        button:hover {
            opacity: .92;
        }

        .pesan {
            padding: 12px;
            margin-bottom: 15px;
            border-radius: 8px;
            background: #fee2e2;
            color: #991b1b;
            font-size: 14px;
            line-height: 1.6;
        }

        .catatan {
            margin-top: 15px;
            font-size: 13px;
            color: #64748b;
            line-height: 1.7;
        }

        @media (max-width: 600px) {
            body {
                padding: 15px;
            }

            .card {
                padding: 18px;
            }

            .header {
                padding: 20px;
            }
        }
    </style>
</head>

<body>
<div class="container">

    <a class="back" href="dashboard.php">
        &larr; Kembali ke Dashboard
    </a>

    <div class="header">
        <h2>Ajukan Peminjaman</h2>
        <p>Formulir peminjaman alat Karang Taruna</p>
    </div>

    <div class="card">
        <h3>Form Pengajuan</h3>

        <?php if ($pesan !== ''): ?>
            <div class="pesan">
                <?= htmlspecialchars($pesan, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="">
            <label for="nama_peminjam">Nama Lengkap Peminjam</label>

            <input
                type="text"
                id="nama_peminjam"
                name="nama_peminjam"
                maxlength="100"
                value="<?= htmlspecialchars(
                    $nama_peminjam,
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>"
                placeholder="Masukkan nama lengkap"
                autocomplete="name"
                required
            >

            <label for="id_alat">Nama Alat</label>

            <select name="id_alat" id="id_alat" required>
                <option value="">-- Pilih Alat --</option>

                <?php while ($alat = mysqli_fetch_assoc($queryAlat)): ?>
                    <?php
                    $kondisiAlat = strtolower(trim($alat['kondisi'] ?? ''));

                    $alatRusakBerat = in_array(
                        $kondisiAlat,
                        ['rusak berat', 'rusak-berat', 'rusak_berat'],
                        true
                    );

                    $stokHabis = (int) $alat['jumlah'] <= 0;
                    $dinonaktifkan = $alatRusakBerat || $stokHabis;
                    ?>

                    <option
                        value="<?= (int) $alat['id_alat'] ?>"
                        <?= (int) ($_POST['id_alat'] ?? 0) === (int) $alat['id_alat'] ? 'selected' : '' ?>
                        <?= $dinonaktifkan ? 'disabled' : '' ?>
                    >
                        <?= htmlspecialchars($alat['nama_alat'], ENT_QUOTES, 'UTF-8') ?>
                        — Stok: <?= (int) $alat['jumlah'] ?>
                        — <?= htmlspecialchars($alat['kondisi'], ENT_QUOTES, 'UTF-8') ?>
                        <?= $dinonaktifkan ? ' (Tidak tersedia)' : '' ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <label for="jumlah_pinjam">Jumlah yang Dipinjam</label>

            <input
                type="number"
                id="jumlah_pinjam"
                name="jumlah_pinjam"
                min="1"
                value="<?= htmlspecialchars(
                    $_POST['jumlah_pinjam'] ?? '1',
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>"
                required
            >

            <label for="tanggal_pinjam">Tanggal Pinjam</label>

            <input
                type="date"
                id="tanggal_pinjam"
                name="tanggal_pinjam"
                min="<?= date('Y-m-d') ?>"
                value="<?= htmlspecialchars(
                    $_POST['tanggal_pinjam'] ?? '',
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>"
                required
            >

            <label for="tanggal_kembali">Tanggal Kembali</label>

            <input
                type="date"
                id="tanggal_kembali"
                name="tanggal_kembali"
                min="<?= date('Y-m-d') ?>"
                value="<?= htmlspecialchars(
                    $_POST['tanggal_kembali'] ?? '',
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>"
                required
            >

            <label for="keperluan">Keperluan Peminjaman</label>

            <textarea
                id="keperluan"
                name="keperluan"
                placeholder="Contoh: Untuk kegiatan kerja bakti Karang Taruna"
                required><?= htmlspecialchars(
                    $_POST['keperluan'] ?? '',
                    ENT_QUOTES,
                    'UTF-8'
                ) ?></textarea>

            <button type="submit">Kirim Pengajuan</button>
        </form>

        <p class="catatan">
            Pengajuan akan berstatus Menunggu sampai diperiksa oleh Admin.
            Stok tidak langsung dikurangi saat pengajuan dibuat.
            Pastikan nama lengkap yang diisi sudah benar.
        </p>
    </div>
</div>

<script>
    const tanggalPinjam = document.getElementById('tanggal_pinjam');
    const tanggalKembali = document.getElementById('tanggal_kembali');

    tanggalPinjam.addEventListener('change', function () {
        tanggalKembali.min = this.value || '<?= date('Y-m-d') ?>';

        if (
            tanggalKembali.value &&
            tanggalKembali.value < tanggalKembali.min
        ) {
            tanggalKembali.value = tanggalKembali.min;
        }
    });
</script>

</body>
</html>
