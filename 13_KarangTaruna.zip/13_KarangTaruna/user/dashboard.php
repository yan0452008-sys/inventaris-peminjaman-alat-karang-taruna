
<?php
session_start();

if (
    !isset($_SESSION['login']) ||
    $_SESSION['login'] !== true ||
    !isset($_SESSION['role']) ||
    $_SESSION['role'] !== 'anggota'
) {
    header("Location: ../login.php");
    exit;
}

include "../koneksi.php";

$id_user = (int) ($_SESSION['id_user'] ?? 0);
$username_asli = $_SESSION['username'] ?? 'Anggota';

if ($id_user <= 0) {
    header("Location: ../logout.php");
    exit;
}

$username = htmlspecialchars(
    $username_asli,
    ENT_QUOTES,
    'UTF-8'
);

$inisial = strtoupper(substr($username_asli, 0, 1));

// Menghitung jenis alat
$qAlat = mysqli_query(
    $conn,
    "SELECT COUNT(*) AS total FROM alat"
);

$totalAlat = $qAlat
    ? (int) mysqli_fetch_assoc($qAlat)['total']
    : 0;

// Menghitung pengajuan milik anggota yang login
$stmtStat = mysqli_prepare($conn, "
    SELECT
        COUNT(*) AS total,
        COALESCE(SUM(status = 'Menunggu'), 0) AS menunggu,
        COALESCE(SUM(status = 'Disetujui'), 0) AS disetujui,
        COALESCE(SUM(status = 'Selesai'), 0) AS selesai
    FROM peminjaman
    WHERE id_user = ?
");

mysqli_stmt_bind_param($stmtStat, "i", $id_user);
mysqli_stmt_execute($stmtStat);

$hasilStat = mysqli_stmt_get_result($stmtStat);
$stat = mysqli_fetch_assoc($hasilStat);

$totalPinjam = (int) ($stat['total'] ?? 0);
$totalMenunggu = (int) ($stat['menunggu'] ?? 0);
$totalDisetujui = (int) ($stat['disetujui'] ?? 0);
$totalSelesai = (int) ($stat['selesai'] ?? 0);

mysqli_stmt_close($stmtStat);

// Riwayat terbaru milik anggota yang login
$stmtRiwayat = mysqli_prepare($conn, "
    SELECT
        p.id_peminjaman,
        p.jumlah_pinjam,
        p.tanggal_pinjam,
        p.status,
        a.nama_alat
    FROM peminjaman p
    LEFT JOIN alat a ON p.id_alat = a.id_alat
    WHERE p.id_user = ?
    ORDER BY p.id_peminjaman DESC
    LIMIT 5
");

mysqli_stmt_bind_param($stmtRiwayat, "i", $id_user);
mysqli_stmt_execute($stmtRiwayat);

$queryTerbaru = mysqli_stmt_get_result($stmtRiwayat);

// Mengambil data riwayat sebelum statement ditutup
$riwayat = [];

if ($queryTerbaru) {
    while ($row = mysqli_fetch_assoc($queryTerbaru)) {
        $riwayat[] = $row;
    }
}

mysqli_stmt_close($stmtRiwayat);
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Dashboard Anggota | Karang Taruna</title>

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: "Segoe UI", Arial, sans-serif;
}

body {
    background: #f1f5f9;
    color: #1e293b;
}

/* SIDEBAR */
.sidebar {
    position: fixed;
    left: 0;
    top: 0;
    width: 250px;
    height: 100vh;
    background: linear-gradient(180deg, #1e3a8a, #312e81);
    color: white;
    padding: 25px 18px;
    z-index: 1000;
    overflow-y: auto;
}

.logo {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 10px;
    margin-bottom: 35px;
}

.logo-icon {
    width: 45px;
    height: 45px;
    flex-shrink: 0;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(255,255,255,.15);
    font-size: 23px;
}

.logo-text h2 {
    font-size: 15px;
    line-height: 1.4;
}

.logo-text span {
    font-size: 11px;
    color: #c7d2fe;
}

.menu-title {
    font-size: 11px;
    color: #a5b4fc;
    margin: 20px 12px 10px;
    text-transform: uppercase;
    letter-spacing: 1px;
}

.menu a {
    display: flex;
    align-items: center;
    gap: 13px;
    color: #e0e7ff;
    text-decoration: none;
    padding: 12px 14px;
    margin: 5px 0;
    border-radius: 10px;
    transition: .3s;
    font-size: 14px;
}

.menu a:hover,
.menu a.active {
    background: rgba(255,255,255,.14);
    color: white;
}

.menu-icon {
    width: 25px;
    flex-shrink: 0;
    text-align: center;
    font-size: 17px;
}

/* LOGOUT */
.logout {
    margin-top: 30px;
}

.logout a {
    color: #fecaca;
    background: rgba(239,68,68,.15);
}

.logout a:hover {
    background: rgba(239,68,68,.28);
}

/* KONTEN UTAMA */
.main {
    margin-left: 250px;
    min-height: 100vh;
}

/* TOPBAR */
.topbar {
    min-height: 75px;
    background: white;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    padding: 15px 35px;
    border-bottom: 1px solid #e2e8f0;
}

.page-title h2 {
    font-size: 20px;
    color: #0f172a;
}

.page-title p {
    font-size: 12px;
    color: #94a3b8;
    margin-top: 3px;
}

.profile {
    display: flex;
    align-items: center;
    gap: 12px;
}

.profile-info {
    text-align: right;
}

.profile-info strong {
    display: block;
    font-size: 13px;
}

.profile-info span {
    font-size: 11px;
    color: #94a3b8;
}

.avatar {
    width: 40px;
    height: 40px;
    flex-shrink: 0;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    background: linear-gradient(135deg, #2563eb, #7c3aed);
    font-weight: bold;
}

/* ISI DASHBOARD */
.content {
    padding: 30px 35px;
}

.welcome {
    background: linear-gradient(135deg, #2563eb, #4f46e5, #7c3aed);
    color: white;
    padding: 28px 30px;
    border-radius: 18px;
    margin-bottom: 25px;
    position: relative;
    overflow: hidden;
}

.welcome::after {
    content: "";
    position: absolute;
    width: 220px;
    height: 220px;
    border-radius: 50%;
    background: rgba(255,255,255,.08);
    right: -70px;
    top: -90px;
    pointer-events: none;
}

.welcome h1 {
    font-size: 25px;
    margin-bottom: 7px;
}

.welcome p {
    color: #dbeafe;
    font-size: 13px;
    line-height: 1.8;
    max-width: 650px;
}

/* STATISTIK */
.stats {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 18px;
    margin-bottom: 25px;
}

.stat-card {
    background: white;
    border-radius: 15px;
    padding: 20px;
    border: 1px solid #e2e8f0;
    transition: .3s;
}

.stat-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 12px 30px rgba(15,23,42,.08);
}

.stat-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
}

.stat-card p {
    font-size: 12px;
    color: #64748b;
}

.stat-card h3 {
    font-size: 27px;
    margin-top: 8px;
    color: #0f172a;
}

.stat-icon {
    width: 45px;
    height: 45px;
    flex-shrink: 0;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 21px;
}

.blue {
    background: #dbeafe;
}

.purple {
    background: #ede9fe;
}

.orange {
    background: #ffedd5;
}

.green {
    background: #dcfce7;
}

/* PANEL DAN TABEL */
.dashboard-grid {
    display: grid;
    grid-template-columns: minmax(0, 2fr) minmax(250px, 1fr);
    gap: 20px;
}

.panel {
    background: white;
    border-radius: 15px;
    border: 1px solid #e2e8f0;
    overflow: hidden;
    min-width: 0;
}

.panel-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    padding: 20px;
    border-bottom: 1px solid #e2e8f0;
}

.panel-header h3 {
    font-size: 16px;
}

.panel-header a {
    color: #2563eb;
    text-decoration: none;
    font-size: 12px;
    white-space: nowrap;
}

.panel-header a:hover {
    text-decoration: underline;
}

.table-container {
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
    min-width: 520px;
}

th {
    text-align: left;
    font-size: 11px;
    color: #94a3b8;
    padding: 14px 16px;
    background: #f8fafc;
}

td {
    padding: 15px 16px;
    border-top: 1px solid #f1f5f9;
    font-size: 12px;
}

tr:hover {
    background: #f8fafc;
}

/* STATUS */
.badge {
    display: inline-block;
    padding: 5px 9px;
    border-radius: 20px;
    font-size: 10px;
    font-weight: 600;
    white-space: nowrap;
}

.badge-menunggu {
    background: #fef3c7;
    color: #92400e;
}

.badge-disetujui {
    background: #dbeafe;
    color: #1d4ed8;
}

.badge-selesai {
    background: #dcfce7;
    color: #166534;
}

.badge-ditolak {
    background: #fee2e2;
    color: #991b1b;
}

/* MENU CEPAT */
.quick-menu {
    padding: 20px;
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 12px;
}

.quick {
    display: block;
    text-decoration: none;
    padding: 18px 10px;
    border-radius: 12px;
    background: #f8fafc;
    color: #334155;
    text-align: center;
    transition: .3s;
    border: 1px solid #f1f5f9;
}

.quick:hover {
    background: #eff6ff;
    border-color: #bfdbfe;
    transform: translateY(-2px);
}

.quick-icon {
    font-size: 25px;
    margin-bottom: 7px;
}

.quick span {
    display: block;
    font-size: 11px;
}

/* INFORMASI */
.info-section {
    margin-top: 25px;
}

.info-section-title {
    margin-bottom: 15px;
}

.info-section-title h3 {
    font-size: 18px;
    margin-bottom: 4px;
}

.info-section-title p {
    font-size: 12px;
    color: #64748b;
}

.info-cards {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 18px;
}

.info-card {
    background: white;
    border: 1px solid #e2e8f0;
    border-radius: 15px;
    padding: 22px;
    transition: .3s;
}

.info-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 25px rgba(15,23,42,.08);
    border-color: #bfdbfe;
}

.info-card-header {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 14px;
}

.info-card-icon {
    width: 42px;
    height: 42px;
    flex-shrink: 0;
    border-radius: 11px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #dbeafe;
    color: #1d4ed8;
    font-size: 19px;
}

.info-card h4 {
    font-size: 15px;
    color: #0f172a;
}

.info-card p,
.info-card li {
    font-size: 12px;
    line-height: 1.8;
    color: #64748b;
}

.info-card ol {
    padding-left: 19px;
}

.info-card li {
    margin-bottom: 3px;
}

.info-card.visi {
    border-top: 4px solid #2563eb;
}

.info-card.misi {
    border-top: 4px solid #4f46e5;
}

.info-card.ketentuan {
    border-top: 4px solid #0ea5e9;
}

.info-card.kegiatan {
    border-top: 4px solid #7c3aed;
}

.info-box {
    margin-top: 20px;
    padding: 16px 20px;
    background: white;
    border: 1px solid #e2e8f0;
    border-radius: 15px;
    color: #64748b;
    font-size: 12px;
    line-height: 1.8;
}

/* RESPONSIVE */
@media (max-width: 1200px) {
    .stats {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    .dashboard-grid {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 700px) {
    .sidebar {
        width: 70px;
        padding: 20px 10px;
    }

    .logo {
        justify-content: center;
        padding: 10px 0;
        margin-bottom: 25px;
    }

    .logo-text,
    .menu-title,
    .menu a span {
        display: none;
    }

    .menu a {
        justify-content: center;
        padding: 12px 5px;
    }

    .menu-icon {
        width: auto;
    }

    .main {
        margin-left: 70px;
    }

    .topbar {
        padding: 15px;
    }

    .page-title h2 {
        font-size: 17px;
    }

    .page-title p {
        max-width: 180px;
        line-height: 1.5;
    }

    .profile-info {
        display: none;
    }

    .content {
        padding: 20px 15px;
    }

    .welcome {
        padding: 23px 20px;
    }

    .welcome h1 {
        font-size: 21px;
    }

    .stats {
        grid-template-columns: 1fr;
    }

    .info-cards {
        grid-template-columns: 1fr;
    }
}
</style>
</head>

<body>

<!-- SIDEBAR -->
<aside class="sidebar">

    <div class="logo">
        <div class="logo-icon">🏘️</div>

        <div class="logo-text">
            <h2>Karang Taruna Manunggal Bhakti</h2>
            <span>Sistem Informasi</span>
        </div>
    </div>

    <div class="menu-title">Menu Anggota</div>

    <nav class="menu">
        <a href="dashboard.php" class="active">
            <div class="menu-icon">🏠</div>
            <span>Dashboard</span>
        </a>

        <a href="anggota.php">
            <div class="menu-icon">👥</div>
            <span>Data Anggota</span>
        </a>

        <a href="alat.php">
            <div class="menu-icon">📦</div>
            <span>Lihat Data Alat</span>
        </a>

        <a href="ajukan_peminjaman.php">
            <div class="menu-icon">📝</div>
            <span>Ajukan Peminjaman</span>
        </a>

        <a href="peminjaman.php">
            <div class="menu-icon">📋</div>
            <span>Status Peminjaman</span>
        </a>
    </nav>

    <div class="menu-title">Akun</div>

    <nav class="menu">
        <a href="logout.php" class="logout"
           onclick="return confirm('Yakin ingin keluar dari akun?')">
            <div class="menu-icon">🚪</div>
            <span>Logout</span>
        </a>
    </nav>

</aside>

<!-- KONTEN UTAMA -->
<main class="main">

    <!-- TOPBAR -->
    <header class="topbar">

        <div class="page-title">
            <h2>Dashboard</h2>
            <p>Sistem Informasi Karang Taruna Manunggal Bhakti</p>
        </div>

        <div class="profile">
            <div class="profile-info">
                <strong><?= $username ?></strong>
                <span>Anggota</span>
            </div>

            <div class="avatar">
                <?= htmlspecialchars($inisial, ENT_QUOTES, 'UTF-8') ?>
            </div>
        </div>

    </header>

    <section class="content">

        <!-- SAMBUTAN -->
        <div class="welcome">
            <h1>Selamat datang kembali, <?= $username ?>!</h1>

            <p>
                Pantau inventaris, ajukan peminjaman, dan periksa
                status pengajuan alat Karang Taruna dari satu tempat.
            </p>
        </div>

        <!-- STATISTIK -->
        <div class="stats">

            <div class="stat-card">
                <div class="stat-top">
                    <div>
                        <p>Jenis Alat</p>
                        <h3><?= $totalAlat ?></h3>
                    </div>

                    <div class="stat-icon blue">📦</div>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-top">
                    <div>
                        <p>Total Pengajuan Saya</p>
                        <h3><?= $totalPinjam ?></h3>
                    </div>

                    <div class="stat-icon purple">📋</div>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-top">
                    <div>
                        <p>Menunggu Persetujuan</p>
                        <h3><?= $totalMenunggu ?></h3>
                    </div>

                    <div class="stat-icon orange">⏳</div>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-top">
                    <div>
                        <p>Disetujui</p>
                        <h3><?= $totalDisetujui ?></h3>
                    </div>

                    <div class="stat-icon green">✓</div>
                </div>
            </div>

        </div>

        <!-- RIWAYAT DAN MENU CEPAT -->
        <div class="dashboard-grid">

            <!-- RIWAYAT TERBARU -->
            <div class="panel">

                <div class="panel-header">
                    <h3>📋 Pengajuan Terbaru Saya</h3>
                    <a href="peminjaman.php">Lihat semua →</a>
                </div>

                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>ALAT</th>
                                <th>JUMLAH</th>
                                <th>TANGGAL</th>
                                <th>STATUS</th>
                            </tr>
                        </thead>

                        <tbody>

                        <?php if (count($riwayat) > 0): ?>

                            <?php foreach ($riwayat as $row): ?>

                                <?php
                                $status = $row['status'] ?? '';

                                $class = match ($status) {
                                    'Menunggu' => 'badge-menunggu',
                                    'Disetujui' => 'badge-disetujui',
                                    'Selesai' => 'badge-selesai',
                                    'Ditolak' => 'badge-ditolak',
                                    default => ''
                                };
                                ?>

                                <tr>
                                    <td>
                                        <?= htmlspecialchars(
                                            $row['nama_alat'] ?? 'Alat tidak ditemukan',
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>
                                    </td>

                                    <td>
                                        <?= (int) $row['jumlah_pinjam'] ?>
                                    </td>

                                    <td>
                                        <?php
                                        if (!empty($row['tanggal_pinjam'])) {
                                            $timestamp = strtotime($row['tanggal_pinjam']);

                                            echo $timestamp !== false
                                                ? date('d/m/Y', $timestamp)
                                                : '-';
                                        } else {
                                            echo '-';
                                        }
                                        ?>
                                    </td>

                                    <td>
                                        <span class="badge <?= $class ?>">
                                            <?= htmlspecialchars(
                                                $status,
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>
                                        </span>
                                    </td>
                                </tr>

                            <?php endforeach; ?>

                        <?php else: ?>

                            <tr>
                                <td colspan="4"
                                    style="text-align:center;color:#94a3b8;padding:35px;">
                                    Belum ada pengajuan peminjaman.
                                </td>
                            </tr>

                        <?php endif; ?>

                        </tbody>
                    </table>
                </div>

            </div>

            <!-- MENU CEPAT -->
            <div class="panel">

                <div class="panel-header">
                    <h3>⚡ Menu Cepat</h3>
                </div>

                <div class="quick-menu">

                    <a href="anggota.php" class="quick">
                        <div class="quick-icon">👥</div>
                        <span>Data Anggota</span>
                    </a>

                    <a href="alat.php" class="quick">
                        <div class="quick-icon">📦</div>
                        <span>Lihat Data Alat</span>
                    </a>

                    <a href="ajukan_peminjaman.php" class="quick">
                        <div class="quick-icon">📝</div>
                        <span>Ajukan Peminjaman</span>
                    </a>

                    <a href="peminjaman.php" class="quick">
                        <div class="quick-icon">📋</div>
                        <span>Status Peminjaman</span>
                    </a>

                    <a href="logout.php" class="quick"
                       onclick="return confirm('Yakin ingin keluar dari akun?')">
                        <div class="quick-icon">🚪</div>
                        <span>Logout</span>
                    </a>

                </div>
            </div>

        </div>

        <!-- INFORMASI KARANG TARUNA -->
        <div class="info-section">

            <div class="info-section-title">
                <h3>Informasi Karang Taruna Manunggal Bhakti</h3>
                <p>
                    Informasi umum, visi, misi, dan ketentuan penggunaan alat.
                </p>
            </div>

            <div class="info-cards">

                <div class="info-card">
                    <div class="info-card-header">
                        <div class="info-card-icon">🏘️</div>
                        <h4>Tentang Karang Taruna</h4>
                    </div>

                    <p>
                        Karang Taruna Manunggal Bhakti merupakan organisasi
                        kepemudaan yang menjadi wadah bagi generasi muda
                        untuk mengembangkan kreativitas, kepedulian sosial,
                        dan berpartisipasi dalam kegiatan masyarakat.
                    </p>
                </div>

                <div class="info-card visi">
                    <div class="info-card-header">
                        <div class="info-card-icon">🎯</div>
                        <h4>Visi</h4>
                    </div>

                    <p>
                        Membangun generasi muda yang aktif, kreatif,
                        berakhlak mulia, dan peduli terhadap kesejahteraan
                        sosial masyarakat.
                    </p>
                </div>

                <div class="info-card misi">
                    <div class="info-card-header">
                        <div class="info-card-icon">📌</div>
                        <h4>Misi</h4>
                    </div>

                    <ol>
                        <li>Mengadakan kegiatan positif kepemudaan secara rutin.</li>
                        <li>Mempererat kerukunan antarwarga dan pemuda.</li>
                        <li>Berpartisipasi dalam kegiatan sosial dan peringatan hari nasional.</li>
                    </ol>
                </div>

                <div class="info-card ketentuan">
                    <div class="info-card-header">
                        <div class="info-card-icon">📋</div>
                        <h4>Ketentuan Peminjaman Alat</h4>
                    </div>

                    <ol>
                        <li>Ajukan peminjaman melalui sistem.</li>
                        <li>Isi data pengajuan dengan benar.</li>
                        <li>Tunggu persetujuan Admin sebelum menggunakan alat.</li>
                        <li>Kembalikan alat sesuai tanggal yang disepakati.</li>
                        <li>Jaga alat dan bertanggung jawab atas penggunaannya.</li>
                    </ol>
                </div>

            </div>
        </div>

        <!-- INFORMASI SISTEM -->
        <div class="info-box">
            <strong style="color:#334155;">Informasi Sistem:</strong>

            Status pengajuan dapat dipantau melalui menu Status Peminjaman.
            Pengajuan berstatus Menunggu perlu diperiksa oleh Admin.
        </div>

    </section>
</main>

</body>
</html>
