<?php
session_start();

if (
    !isset($_SESSION['login']) ||
    $_SESSION['login'] !== true ||
    !isset($_SESSION['role']) ||
    $_SESSION['role'] !== 'anggota'
) {
    header("Location: ../login.php");
    exit;
}

include "../koneksi.php";

$id_user = (int) ($_SESSION['id_user'] ?? 0);
$username = htmlspecialchars(
    $_SESSION['username'] ?? '',
    ENT_QUOTES,
    'UTF-8'
);

if ($id_user <= 0) {
    die("ID akun tidak ditemukan. Silakan login kembali.");
}

$stmt = mysqli_prepare($conn, "
    SELECT p.id_peminjaman, a.nama_alat, p.jumlah_pinjam,
           p.tanggal_pinjam, p.tanggal_kembali,
           p.keperluan, p.status
    FROM peminjaman p
    LEFT JOIN alat a ON p.id_alat = a.id_alat
    WHERE p.id_user = ?
    ORDER BY p.id_peminjaman DESC
");

mysqli_stmt_bind_param($stmt, "i", $id_user);
mysqli_stmt_execute($stmt);
$data = mysqli_stmt_get_result($stmt);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Peminjaman Saya - Karang Taruna</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 25px;
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            color: #1e293b;
        }

        .container {
            max-width: 1200px;
            margin: auto;
        }

        .header {
            padding: 25px;
            border-radius: 16px;
            color: white;
            background: linear-gradient(135deg, #1e3a8a, #4f46e5);
            margin-bottom: 22px;
        }

        .header h1 {
            margin: 0 0 8px;
        }

        .header p {
            margin: 0;
        }

        .back {
            display: inline-block;
            margin-bottom: 18px;
            color: #2563eb;
            text-decoration: none;
            font-weight: bold;
        }

        .card {
            background: white;
            padding: 22px;
            border-radius: 16px;
            box-shadow: 0 4px 15px rgba(15, 23, 42, 0.06);
        }

        .success {
            padding: 14px;
            margin-bottom: 18px;
            border-radius: 10px;
            background: #dcfce7;
            color: #166534;
        }

        .table-wrap {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 850px;
        }

        th, td {
            padding: 13px;
            border-bottom: 1px solid #e2e8f0;
            text-align: left;
        }

        th {
            background: #eff6ff;
            color: #1e40af;
        }

        .status {
            display: inline-block;
            padding: 6px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            background: #fef3c7;
            color: #92400e;
        }

        .empty {
            padding: 25px;
            text-align: center;
            color: #64748b;
        }

        .button {
            display: inline-block;
            margin-top: 18px;
            padding: 11px 16px;
            border-radius: 9px;
            color: white;
            text-decoration: none;
            background: linear-gradient(135deg, #2563eb, #4f46e5);
        }

        @media (max-width: 600px) {
            body {
                padding: 14px;
            }

            .card {
                padding: 14px;
            }
        }
    </style>
</head>

<body>
<div class="container">

    <a class="back" href="dashboard.php">
        &larr; Kembali ke Dashboard
    </a>

    <div class="header">
        <h1>Peminjaman Saya</h1>
        <p>Halo, <?= $username ?>. Pantau status pengajuan alat kamu di sini.</p>
    </div>

    <div class="card">

        <?php if (isset($_GET['pengajuan']) && $_GET['pengajuan'] === 'berhasil'): ?>
            <div class="success">
                Pengajuan berhasil dikirim! Silakan tunggu persetujuan Admin.
            </div>
        <?php endif; ?>

        <h2>Riwayat Pengajuan</h2>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Nama Alat</th>
                        <th>Jumlah</th>
                        <th>Tanggal Pinjam</th>
                        <th>Tanggal Kembali</th>
                        <th>Keperluan</th>
                        <th>Status</th>
                    </tr>
                </thead>

                <tbody>
                <?php if (mysqli_num_rows($data) > 0): ?>
                    <?php $no = 1; ?>
                    <?php while ($row = mysqli_fetch_assoc($data)): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= htmlspecialchars($row['nama_alat'] ?? 'Alat tidak ditemukan') ?></td>
                            <td><?= (int) $row['jumlah_pinjam'] ?></td>
                            <td><?= htmlspecialchars($row['tanggal_pinjam']) ?></td>
                            <td><?= htmlspecialchars($row['tanggal_kembali']) ?></td>
                            <td><?= htmlspecialchars($row['keperluan']) ?></td>
                            <td>
                                <span class="status">
                                    <?= htmlspecialchars($row['status']) ?>
                                </span>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="empty">
                            Belum ada pengajuan peminjaman.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <a class="button" href="ajukan_peminjaman.php">
            + Ajukan Peminjaman
        </a>

    </div>
</div>
</body>
</html>

<?php
mysqli_stmt_close($stmt);
?>
