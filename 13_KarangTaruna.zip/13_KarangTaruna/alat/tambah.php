<?php

session_start();

if (!isset($_SESSION['login'])) {
    header("Location: ../login.php");
    exit;
}

include "../koneksi.php";

if (isset($_POST['simpan'])) {

    $nama_alat = mysqli_real_escape_string(
        $conn,
        $_POST['nama_alat']
    );

    $kategori = mysqli_real_escape_string(
        $conn,
        $_POST['kategori']
    );

    $jumlah = (int) $_POST['jumlah'];

    $kondisi = mysqli_real_escape_string(
        $conn,
        $_POST['kondisi']
    );

    $lokasi = mysqli_real_escape_string(
        $conn,
        $_POST['lokasi']
    );

    $keterangan = mysqli_real_escape_string(
        $conn,
        $_POST['keterangan']
    );


    $query = mysqli_query($conn, "
        INSERT INTO alat
        (
            nama_alat,
            kategori,
            jumlah,
            kondisi,
            lokasi,
            keterangan
        )
        VALUES
        (
            '$nama_alat',
            '$kategori',
            '$jumlah',
            '$kondisi',
            '$lokasi',
            '$keterangan'
        )
    ");


    if ($query) {

        header("Location: index.php");
        exit;

    } else {

        $error = "Data alat gagal disimpan.";

    }

}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Tambah Alat | Karang Taruna</title>

    <style>

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: "Segoe UI", Arial, sans-serif;
        }

        body {
            background: #f1f5f9;
            color: #1e293b;
        }

        .container {
            max-width: 850px;
            margin: 40px auto;
            padding: 20px;
        }

        .header {
            margin-bottom: 22px;
        }

        .header h1 {
            font-size: 26px;
            color: #0f172a;
        }

        .header p {
            color: #64748b;
            font-size: 13px;
            margin-top: 5px;
        }

        .card {
            background: white;
            border-radius: 18px;
            padding: 32px;
            border: 1px solid #e2e8f0;
            box-shadow:
                0 10px 30px rgba(15,23,42,0.06);
        }

        .card-title {
            display: flex;
            align-items: center;
            gap: 14px;
            padding-bottom: 22px;
            margin-bottom: 25px;
            border-bottom: 1px solid #e2e8f0;
        }

        .icon {
            width: 48px;
            height: 48px;
            border-radius: 13px;
            background: linear-gradient(
                135deg,
                #dbeafe,
                #ede9fe
            );
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 23px;
        }

        .card-title h2 {
            font-size: 18px;
            color: #0f172a;
        }

        .card-title p {
            color: #94a3b8;
            font-size: 12px;
            margin-top: 3px;
        }

        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .full {
            grid-column: 1 / 3;
        }

        label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: #334155;
            margin-bottom: 8px;
        }

        .required {
            color: #ef4444;
        }

        input,
        select,
        textarea {
            width: 100%;
            padding: 12px 14px;
            border: 1px solid #cbd5e1;
            border-radius: 9px;
            outline: none;
            font-size: 14px;
            color: #334155;
            background: white;
            transition: 0.2s;
        }

        input:focus,
        select:focus,
        textarea:focus {
            border-color: #2563eb;
            box-shadow:
                0 0 0 3px rgba(37,99,235,0.1);
        }

        input::placeholder,
        textarea::placeholder {
            color: #94a3b8;
        }

        textarea {
            min-height: 110px;
            resize: vertical;
        }

        .helper {
            color: #94a3b8;
            font-size: 11px;
            margin-top: 6px;
        }

        .error {
            background: #fee2e2;
            color: #b91c1c;
            padding: 13px 15px;
            border-radius: 9px;
            margin-bottom: 20px;
            font-size: 13px;
        }

        .button-group {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 10px;
            padding-top: 22px;
            border-top: 1px solid #e2e8f0;
        }

        .btn {
            padding: 12px 20px;
            border-radius: 9px;
            text-decoration: none;
            border: none;
            cursor: pointer;
            font-size: 13px;
            font-weight: 600;
        }

        .btn-simpan {
            background: linear-gradient(
                135deg,
                #2563eb,
                #4f46e5
            );
            color: white;
            box-shadow:
                0 7px 18px rgba(37,99,235,0.2);
        }

        .btn-simpan:hover {
            transform: translateY(-1px);
        }

        .btn-kembali {
            background: #e2e8f0;
            color: #334155;
        }

        @media(max-width:650px) {

            .container {
                margin: 20px auto;
                padding: 12px;
            }

            .card {
                padding: 22px;
            }

            .form-grid {
                grid-template-columns: 1fr;
            }

            .full {
                grid-column: auto;
            }

            .button-group {
                flex-direction: column;
            }

            .btn {
                text-align: center;
            }

        }

    </style>

</head>

<body>

<div class="container">

    <div class="header">

        <h1>
            📦 Tambah Alat
        </h1>

        <p>
            Tambahkan inventaris baru ke dalam sistem Karang Taruna
        </p>

    </div>


    <div class="card">

        <div class="card-title">

            <div class="icon">
                📦
            </div>

            <div>

                <h2>
                    Informasi Alat
                </h2>

                <p>
                    Isi informasi alat dengan lengkap
                </p>

            </div>

        </div>


        <?php if (isset($error)): ?>

            <div class="error">

                ⚠️
                <?php echo $error; ?>

            </div>

        <?php endif; ?>


        <form method="POST">

            <div class="form-grid">


                <!-- NAMA ALAT -->

                <div class="form-group">

                    <label>
                        Nama Alat
                        <span class="required">*</span>
                    </label>

                    <input
                        type="text"
                        name="nama_alat"
                        placeholder="Contoh: Sound System"
                        required
                    >

                    <div class="helper">
                        Masukkan nama alat/inventaris
                    </div>

                </div>


                <!-- KATEGORI -->

                <div class="form-group">

                    <label>
                        Kategori
                        <span class="required">*</span>
                    </label>

                    <select
                        name="kategori"
                        required
                    >

                        <option value="">
                            -- Pilih Kategori --
                        </option>

                        <option value="Elektronik">
                            Elektronik
                        </option>

                        <option value="Perlengkapan">
                            Perlengkapan
                        </option>

                        <option value="Acara">
                            Acara
                        </option>

                        <option value="Olahraga">
                            Olahraga
                        </option>

                        <option value="Kebersihan">
                            Kebersihan
                        </option>

                        <option value="Lainnya">
                            Lainnya
                        </option>

                    </select>

                </div>


                <!-- JUMLAH -->

                <div class="form-group">

                    <label>
                        Jumlah
                        <span class="required">*</span>
                    </label>

                    <input
                        type="number"
                        name="jumlah"
                        min="0"
                        value="1"
                        required
                    >

                    <div class="helper">
                        Jumlah unit alat yang tersedia
                    </div>

                </div>


                <!-- KONDISI -->

                <div class="form-group">

                    <label>
                        Kondisi
                        <span class="required">*</span>
                    </label>

                    <select
                        name="kondisi"
                        required
                    >

                        <option value="">
                            -- Pilih Kondisi --
                        </option>

                        <option value="Baik">
                            Baik
                        </option>

                        <option value="Rusak Ringan">
                            Rusak Ringan
                        </option>

                        <option value="Rusak Berat">
                            Rusak Berat
                        </option>

                    </select>

                </div>


                <!-- LOKASI -->

                <div class="form-group full">

                    <label>
                        Lokasi Penyimpanan
                    </label>

                    <input
                        type="text"
                        name="lokasi"
                        placeholder="Contoh: Gudang Karang Taruna"
                    >

                    <div class="helper">
                        Masukkan lokasi alat disimpan
                    </div>

                </div>


                <!-- KETERANGAN -->

                <div class="form-group full">

                    <label>
                        Keterangan
                    </label>

                    <textarea
                        name="keterangan"
                        placeholder="Contoh: Lengkap dan masih berfungsi dengan baik"
                    ></textarea>

                </div>


            </div>


            <div class="button-group">

                <a
                    href="index.php"
                    class="btn btn-kembali"
                >
                    ← Kembali
                </a>

                <button
                    type="submit"
                    name="simpan"
                    class="btn btn-simpan"
                >
                    💾 Simpan Alat
                </button>

            </div>

        </form>

    </div>

</div>

</body>

</html>
