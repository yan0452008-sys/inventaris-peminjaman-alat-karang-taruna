<?php

session_start();

if (!isset($_SESSION['login'])) {
    header("Location: ../login.php");
    exit;
}

include "../koneksi.php";

$query = mysqli_query($conn, "
    SELECT * FROM alat
    ORDER BY id_alat DESC
");

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Data Alat | Karang Taruna</title>

    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Segoe UI", Arial, sans-serif;
        }

        body {
            background: #f1f5f9;
            color: #1e293b;
        }

        /* SIDEBAR */

        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 250px;
            height: 100vh;
            background: linear-gradient(180deg, #1e3a8a, #312e81);
            color: white;
            padding: 25px 18px;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px;
            margin-bottom: 35px;
        }

        .logo-icon {
            width: 45px;
            height: 45px;
            border-radius: 12px;
            background: rgba(255,255,255,0.15);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 23px;
        }

        .logo-text h2 {
            font-size: 17px;
        }

        .logo-text span {
            font-size: 11px;
            color: #c7d2fe;
        }

        .menu-title {
            font-size: 11px;
            color: #a5b4fc;
            margin: 20px 12px 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .menu a {
            display: flex;
            align-items: center;
            gap: 13px;
            color: #e0e7ff;
            text-decoration: none;
            padding: 12px 14px;
            margin: 5px 0;
            border-radius: 10px;
            font-size: 14px;
            transition: 0.3s;
        }

        .menu a:hover,
        .menu a.active {
            background: rgba(255,255,255,0.14);
            color: white;
        }

        .menu-icon {
            width: 25px;
            text-align: center;
            font-size: 17px;
        }

        .logout {
            position: absolute;
            bottom: 25px;
            left: 18px;
            right: 18px;
        }

        .logout a {
            display: flex;
            align-items: center;
            gap: 13px;
            color: #fecaca;
            text-decoration: none;
            padding: 12px 14px;
            border-radius: 10px;
            background: rgba(239,68,68,0.15);
        }

        /* MAIN */

        .main {
            margin-left: 250px;
            min-height: 100vh;
        }

        .topbar {
            height: 75px;
            background: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 35px;
            border-bottom: 1px solid #e2e8f0;
        }

        .page-title h2 {
            font-size: 20px;
        }

        .page-title p {
            font-size: 12px;
            color: #94a3b8;
            margin-top: 3px;
        }

        .admin {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .admin-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg,#2563eb,#7c3aed);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }

        .admin-info {
            text-align: right;
        }

        .admin-info strong {
            display: block;
            font-size: 13px;
        }

        .admin-info span {
            font-size: 11px;
            color: #94a3b8;
        }

        /* CONTENT */

        .content {
            padding: 30px 35px;
        }

        .header-content {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 25px;
        }

        .header-content h1 {
            font-size: 25px;
            color: #0f172a;
        }

        .header-content p {
            color: #64748b;
            font-size: 13px;
            margin-top: 5px;
        }

        .btn-tambah {
            background: linear-gradient(135deg,#2563eb,#4f46e5);
            color: white;
            text-decoration: none;
            padding: 12px 18px;
            border-radius: 10px;
            font-size: 13px;
            box-shadow: 0 8px 20px rgba(37,99,235,0.2);
        }

        /* CARD */

        .card {
            background: white;
            border: 1px solid #e2e8f0;
            border-radius: 15px;
            overflow: hidden;
        }

        .card-header {
            padding: 20px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .card-header h3 {
            font-size: 16px;
        }

        .search {
            padding: 9px 13px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            outline: none;
            width: 220px;
        }

        .search:focus {
            border-color: #2563eb;
        }

        /* TABLE */

        .table-container {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            text-align: left;
            padding: 14px 20px;
            background: #f8fafc;
            color: #64748b;
            font-size: 11px;
            text-transform: uppercase;
        }

        td {
            padding: 15px 20px;
            border-top: 1px solid #f1f5f9;
            font-size: 13px;
        }

        tr:hover {
            background: #f8fafc;
        }

        .alat-icon {
            width: 38px;
            height: 38px;
            border-radius: 10px;
            background: #ede9fe;
            color: #6d28d9;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin-right: 8px;
            vertical-align: middle;
        }

        .badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 10px;
            font-weight: 600;
        }

        .baik {
            background: #dcfce7;
            color: #166534;
        }

        .rusak-ringan {
            background: #fef3c7;
            color: #92400e;
        }

        .rusak-berat {
            background: #fee2e2;
            color: #991b1b;
        }

        .action {
            display: flex;
            gap: 7px;
        }

        .btn-edit,
        .btn-hapus {
            padding: 7px 10px;
            border-radius: 7px;
            text-decoration: none;
            font-size: 11px;
        }

        .btn-edit {
            background: #dbeafe;
            color: #1d4ed8;
        }

        .btn-hapus {
            background: #fee2e2;
            color: #b91c1c;
        }

        .empty {
            text-align: center;
            padding: 50px;
            color: #94a3b8;
        }

        @media(max-width:800px) {

            .sidebar {
                width: 70px;
                padding: 20px 10px;
            }

            .logo-text,
            .menu-title,
            .menu a span {
                display: none;
            }

            .logo {
                justify-content: center;
            }

            .menu a {
                justify-content: center;
            }

            .main {
                margin-left: 70px;
            }

            .content {
                padding: 20px 15px;
            }

            .admin-info {
                display: none;
            }

            .header-content {
                align-items: flex-start;
                gap: 15px;
            }

            .search {
                width: 150px;
            }
        }

    </style>

</head>

<body>

<!-- SIDEBAR -->

<aside class="sidebar">

    <div class="logo">

        <div class="logo-icon">
            🏘️
        </div>

        <div class="logo-text">
            <h2>Karang Taruna</h2>
            <span>Sistem Informasi</span>
        </div>

    </div>

    <div class="menu-title">
        Menu Utama
    </div>

    <nav class="menu">

        <a href="../dashboard.php">
            <div class="menu-icon">🏠</div>
            <span>Dashboard</span>
        </a>

        <a href="../anggota/index.php">
            <div class="menu-icon">👥</div>
            <span>Data Anggota</span>
        </a>

        <a href="index.php" class="active">
            <div class="menu-icon">📦</div>
            <span>Data Alat</span>
        </a>

        <a href="../peminjaman/index.php">
            <div class="menu-icon">📋</div>
            <span>Peminjaman</span>
        </a>

        <a href="../pengembalian/index.php">
            <div class="menu-icon">🔄</div>
            <span>Pengembalian</span>
        </a>


        <a href="../laporan/peminjaman.php">
            <div class="menu-icon">📊</div>
            <span>Laporan</span>
        </a>

    </nav>

    <div class="logout">

        <a href="../logout.php">
            <div class="menu-icon">🚪</div>
            <span>Logout</span>
        </a>

    </div>

</aside>


<!-- MAIN -->

<main class="main">

    <header class="topbar">

        <div class="page-title">

            <h2>Data Alat</h2>

            <p>
                Inventaris Karang Taruna
            </p>

        </div>

        <div class="admin">

            <div class="admin-info">

                <strong>
                    <?php echo htmlspecialchars($_SESSION['username']); ?>
                </strong>

                <span>
                    Pengurus
                </span>

            </div>

            <div class="admin-avatar">

                <?php
                echo strtoupper(
                    substr($_SESSION['username'], 0, 1)
                );
                ?>

            </div>

        </div>

    </header>


    <section class="content">

        <div class="header-content">

            <div>

                <h1>
                    📦 Data Alat
                </h1>

                <p>
                    Kelola inventaris dan kondisi alat Karang Taruna
                </p>

            </div>

            <a href="tambah.php" class="btn-tambah">
                + Tambah Alat
            </a>

        </div>


        <div class="card">

            <div class="card-header">

                <h3>
                    Daftar Inventaris
                </h3>

                <input
                    type="text"
                    id="search"
                    class="search"
                    placeholder="🔎 Cari alat..."
                >

            </div>


            <div class="table-container">

                <table>

                    <thead>

                        <tr>

                            <th>No</th>

                            <th>Nama Alat</th>

                            <th>Kategori</th>

                            <th>Jumlah</th>

                            <th>Kondisi</th>

                            <th>Lokasi</th>

                            <th>Keterangan</th>

                            <th>Aksi</th>

                        </tr>

                    </thead>


                    <tbody id="tableBody">

                    <?php

                    $no = 1;

                    if (mysqli_num_rows($query) > 0):

                        while ($row = mysqli_fetch_assoc($query)):

                    ?>

                        <tr>

                            <td>
                                <?php echo $no++; ?>
                            </td>


                            <td>

                                <span class="alat-icon">
                                    📦
                                </span>

                                <strong>
                                    <?php
                                    echo htmlspecialchars(
                                        $row['nama_alat']
                                    );
                                    ?>
                                </strong>

                            </td>


                            <td>

                                <?php
                                echo htmlspecialchars(
                                    $row['kategori']
                                );
                                ?>

                            </td>


                            <td>

                                <strong>
                                    <?php
                                    echo $row['jumlah'];
                                    ?>
                                </strong>
                                unit

                            </td>


                            <td>

                                <?php

                                $kondisi = $row['kondisi'];

                                if ($kondisi == 'Baik') {

                                    $class = 'baik';

                                } elseif ($kondisi == 'Rusak Ringan') {

                                    $class = 'rusak-ringan';

                                } else {

                                    $class = 'rusak-berat';

                                }

                                ?>

                                <span class="badge <?php echo $class; ?>">

                                    <?php
                                    echo htmlspecialchars($kondisi);
                                    ?>

                                </span>

                            </td>


                            <td>

                                <?php
                                echo htmlspecialchars(
                                    $row['lokasi']
                                );
                                ?>

                            </td>


                            <td>

                                <?php
                                echo htmlspecialchars(
                                    $row['keterangan']
                                );
                                ?>

                            </td>


                            <td>

                                <div class="action">

                                    <a
                                        href="edit.php?id=<?php echo $row['id_alat']; ?>"
                                        class="btn-edit"
                                    >
                                        ✏️ Edit
                                    </a>

                                    <a
                                        href="hapus.php?id=<?php echo $row['id_alat']; ?>"
                                        class="btn-hapus"
                                        onclick="return confirm('Yakin ingin menghapus alat ini?')"
                                    >
                                        🗑️ Hapus
                                    </a>

                                </div>

                            </td>

                        </tr>

                    <?php

                        endwhile;

                    else:

                    ?>

                        <tr>

                            <td
                                colspan="8"
                                class="empty"
                            >

                                📦

                                <br><br>

                                Belum ada data alat.

                                <br>

                                Silakan klik
                                <strong>Tambah Alat</strong>
                                untuk memasukkan inventaris.

                            </td>

                        </tr>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </div>

    </section>

</main>


<script>

document
.getElementById("search")
.addEventListener("keyup", function () {

    let keyword =
        this.value.toLowerCase();

    let rows =
        document.querySelectorAll(
            "#tableBody tr"
        );

    rows.forEach(function(row) {

        let text =
            row.textContent.toLowerCase();

        if (text.includes(keyword)) {

            row.style.display = "";

        } else {

            row.style.display = "none";

        }

    });

});

</script>

</body>

</html>
