<?php

session_start();

if (!isset($_SESSION['login'])) {
    header("Location: ../login.php");
    exit;
}

include "../koneksi.php";

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$id = (int) $_GET['id'];

$query = mysqli_query($conn, "
    SELECT * FROM alat
    WHERE id_alat = '$id'
");

$data = mysqli_fetch_assoc($query);

if (!$data) {
    echo "Data alat tidak ditemukan.";
    exit;
}


if (isset($_POST['update'])) {

    $nama_alat = mysqli_real_escape_string(
        $conn,
        $_POST['nama_alat']
    );

    $kategori = mysqli_real_escape_string(
        $conn,
        $_POST['kategori']
    );

    $jumlah = (int) $_POST['jumlah'];

    $kondisi = mysqli_real_escape_string(
        $conn,
        $_POST['kondisi']
    );

    $lokasi = mysqli_real_escape_string(
        $conn,
        $_POST['lokasi']
    );

    $keterangan = mysqli_real_escape_string(
        $conn,
        $_POST['keterangan']
    );


    $update = mysqli_query($conn, "
        UPDATE alat SET

            nama_alat = '$nama_alat',

            kategori = '$kategori',

            jumlah = '$jumlah',

            kondisi = '$kondisi',

            lokasi = '$lokasi',

            keterangan = '$keterangan'

        WHERE id_alat = '$id'
    ");


    if ($update) {

        header("Location: index.php");
        exit;

    } else {

        $error = "Data alat gagal diperbarui.";

    }

}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Edit Alat | Karang Taruna</title>

    <style>

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: "Segoe UI", Arial, sans-serif;
        }

        body {
            background: #f1f5f9;
            color: #1e293b;
        }

        .container {
            max-width: 850px;
            margin: 40px auto;
            padding: 20px;
        }

        .header {
            margin-bottom: 22px;
        }

        .header h1 {
            font-size: 26px;
            color: #0f172a;
        }

        .header p {
            color: #64748b;
            font-size: 13px;
            margin-top: 5px;
        }

        .card {
            background: white;
            border-radius: 18px;
            padding: 32px;
            border: 1px solid #e2e8f0;
            box-shadow: 0 10px 30px rgba(15,23,42,0.06);
        }

        .card-title {
            display: flex;
            align-items: center;
            gap: 14px;
            padding-bottom: 22px;
            margin-bottom: 25px;
            border-bottom: 1px solid #e2e8f0;
        }

        .icon {
            width: 48px;
            height: 48px;
            border-radius: 13px;
            background: linear-gradient(
                135deg,
                #dbeafe,
                #ede9fe
            );
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 23px;
        }

        .card-title h2 {
            font-size: 18px;
        }

        .card-title p {
            color: #94a3b8;
            font-size: 12px;
            margin-top: 3px;
        }

        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .full {
            grid-column: 1 / 3;
        }

        label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: #334155;
            margin-bottom: 8px;
        }

        .required {
            color: #ef4444;
        }

        input,
        select,
        textarea {
            width: 100%;
            padding: 12px 14px;
            border: 1px solid #cbd5e1;
            border-radius: 9px;
            outline: none;
            font-size: 14px;
            color: #334155;
            background: white;
        }

        input:focus,
        select:focus,
        textarea:focus {
            border-color: #2563eb;
            box-shadow: 0 0 0 3px rgba(37,99,235,0.1);
        }

        textarea {
            min-height: 110px;
            resize: vertical;
        }

        .error {
            background: #fee2e2;
            color: #b91c1c;
            padding: 13px 15px;
            border-radius: 9px;
            margin-bottom: 20px;
            font-size: 13px;
        }

        .button-group {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 10px;
            padding-top: 22px;
            border-top: 1px solid #e2e8f0;
        }

        .btn {
            padding: 12px 20px;
            border-radius: 9px;
            text-decoration: none;
            border: none;
            cursor: pointer;
            font-size: 13px;
            font-weight: 600;
        }

        .btn-update {
            background: linear-gradient(
                135deg,
                #2563eb,
                #4f46e5
            );
            color: white;
        }

        .btn-kembali {
            background: #e2e8f0;
            color: #334155;
        }

        @media(max-width:650px) {

            .form-grid {
                grid-template-columns: 1fr;
            }

            .full {
                grid-column: auto;
            }

            .button-group {
                flex-direction: column;
            }

            .btn {
                text-align: center;
            }

        }

    </style>

</head>

<body>

<div class="container">

    <div class="header">

        <h1>
            ✏️ Edit Data Alat
        </h1>

        <p>
            Perbarui informasi inventaris Karang Taruna
        </p>

    </div>


    <div class="card">

        <div class="card-title">

            <div class="icon">
                📦
            </div>

            <div>

                <h2>
                    Informasi Alat
                </h2>

                <p>
                    Ubah data alat yang diperlukan
                </p>

            </div>

        </div>


        <?php if (isset($error)): ?>

            <div class="error">
                ⚠️ <?php echo $error; ?>
            </div>

        <?php endif; ?>


        <form method="POST">

            <div class="form-grid">


                <div class="form-group">

                    <label>
                        Nama Alat
                        <span class="required">*</span>
                    </label>

                    <input
                        type="text"
                        name="nama_alat"
                        value="<?php
                            echo htmlspecialchars(
                                $data['nama_alat']
                            );
                        ?>"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>
                        Kategori
                        <span class="required">*</span>
                    </label>

                    <select name="kategori" required>

                        <?php
                        $kategori = $data['kategori'];
                        ?>

                        <option value="Elektronik"
                            <?php
                            if ($kategori == 'Elektronik')
                                echo 'selected';
                            ?>>
                            Elektronik
                        </option>

                        <option value="Perlengkapan"
                            <?php
                            if ($kategori == 'Perlengkapan')
                                echo 'selected';
                            ?>>
                            Perlengkapan
                        </option>

                        <option value="Acara"
                            <?php
                            if ($kategori == 'Acara')
                                echo 'selected';
                            ?>>
                            Acara
                        </option>

                        <option value="Olahraga"
                            <?php
                            if ($kategori == 'Olahraga')
                                echo 'selected';
                            ?>>
                            Olahraga
                        </option>

                        <option value="Kebersihan"
                            <?php
                            if ($kategori == 'Kebersihan')
                                echo 'selected';
                            ?>>
                            Kebersihan
                        </option>

                        <option value="Lainnya"
                            <?php
                            if ($kategori == 'Lainnya')
                                echo 'selected';
                            ?>>
                            Lainnya
                        </option>

                    </select>

                </div>


                <div class="form-group">

                    <label>
                        Jumlah
                        <span class="required">*</span>
                    </label>

                    <input
                        type="number"
                        name="jumlah"
                        min="0"
                        value="<?php
                            echo $data['jumlah'];
                        ?>"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>
                        Kondisi
                        <span class="required">*</span>
                    </label>

                    <select name="kondisi" required>

                        <option value="Baik"
                            <?php
                            if ($data['kondisi'] == 'Baik')
                                echo 'selected';
                            ?>>
                            Baik
                        </option>

                        <option value="Rusak Ringan"
                            <?php
                            if ($data['kondisi'] == 'Rusak Ringan')
                                echo 'selected';
                            ?>>
                            Rusak Ringan
                        </option>

                        <option value="Rusak Berat"
                            <?php
                            if ($data['kondisi'] == 'Rusak Berat')
                                echo 'selected';
                            ?>>
                            Rusak Berat
                        </option>

                    </select>

                </div>


                <div class="form-group full">

                    <label>
                        Lokasi Penyimpanan
                    </label>

                    <input
                        type="text"
                        name="lokasi"
                        value="<?php
                            echo htmlspecialchars(
                                $data['lokasi']
                            );
                        ?>"
                        placeholder="Contoh: Gudang Karang Taruna"
                    >

                </div>


                <div class="form-group full">

                    <label>
                        Keterangan
                    </label>

                    <textarea
                        name="keterangan"
                    ><?php
                        echo htmlspecialchars(
                            $data['keterangan']
                        );
                    ?></textarea>

                </div>

            </div>


            <div class="button-group">

                <a
                    href="index.php"
                    class="btn btn-kembali"
                >
                    ← Kembali
                </a>

                <button
                    type="submit"
                    name="update"
                    class="btn btn-update"
                >
                    💾 Simpan Perubahan
                </button>

            </div>

        </form>

    </div>

</div>

</body>

</html>
