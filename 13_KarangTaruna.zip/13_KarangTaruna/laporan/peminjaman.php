
<?php
date_default_timezone_set('Asia/Jakarta');

session_start();

if (
    !isset($_SESSION['login']) ||
    $_SESSION['login'] !== true ||
    !isset($_SESSION['role']) ||
    $_SESSION['role'] !== 'admin'
) {
    header("Location: ../login.php");
    exit;
}

include "../koneksi.php";

// =========================
// AMBIL DATA PEMINJAMAN
// =========================

$sql = "
    SELECT
        p.*,
        al.nama_alat
    FROM peminjaman p
    LEFT JOIN alat al
        ON p.id_alat = al.id_alat
    ORDER BY p.id_peminjaman DESC
";

$query = mysqli_query($conn, $sql);

if (!$query) {
    die("Gagal mengambil data: " . mysqli_error($conn));
}

$total = mysqli_num_rows($query);

function e($value) {
    return htmlspecialchars((string)($value ?? '-'), ENT_QUOTES, 'UTF-8');
}

function tanggalIndonesia($tanggal) {
    if (empty($tanggal) || $tanggal === '0000-00-00') {
        return '-';
    }

    $timestamp = strtotime($tanggal);

    return $timestamp ? date('d-m-Y', $timestamp) : '-';
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Laporan Peminjaman | Karang Taruna</title>

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: "Segoe UI", Arial, sans-serif;
}

body {
    background: #f1f5f9;
    color: #1e293b;
}

/* SIDEBAR */
.sidebar {
    position: fixed;
    left: 0;
    top: 0;
    width: 250px;
    height: 100vh;
    background: linear-gradient(180deg, #1e3a8a, #312e81);
    color: white;
    padding: 25px 18px;
    z-index: 1000;
}

.logo {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 10px;
    margin-bottom: 35px;
}

.logo-icon {
    width: 45px;
    height: 45px;
    flex-shrink: 0;
    border-radius: 12px;
    background: rgba(255,255,255,.15);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 23px;
}

.logo-text h2 {
    font-size: 17px;
}

.logo-text span {
    font-size: 11px;
    color: #c7d2fe;
}

.menu-title {
    font-size: 11px;
    color: #a5b4fc;
    margin: 20px 12px 10px;
    text-transform: uppercase;
    letter-spacing: 1px;
}

.menu a {
    display: flex;
    align-items: center;
    gap: 13px;
    color: #e0e7ff;
    text-decoration: none;
    padding: 12px 14px;
    margin: 5px 0;
    border-radius: 10px;
    font-size: 14px;
    transition: .3s;
}

.menu a:hover,
.menu a.active {
    background: rgba(255,255,255,.14);
    color: white;
}

.menu-icon {
    width: 25px;
    flex-shrink: 0;
    text-align: center;
    font-size: 17px;
}

.logout {
    position: absolute;
    bottom: 25px;
    left: 18px;
    right: 18px;
}

.logout a {
    display: flex;
    align-items: center;
    gap: 13px;
    color: #fecaca;
    text-decoration: none;
    padding: 12px 14px;
    border-radius: 10px;
    background: rgba(239,68,68,.15);
}

/* MAIN */
.main {
    margin-left: 250px;
    min-height: 100vh;
}

/* TOPBAR */
.topbar {
    min-height: 75px;
    background: white;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    padding: 15px 35px;
    border-bottom: 1px solid #e2e8f0;
}

.page-title h2 {
    font-size: 20px;
    color: #0f172a;
}

.page-title p {
    font-size: 12px;
    color: #94a3b8;
    margin-top: 3px;
}

.admin {
    display: flex;
    align-items: center;
    gap: 12px;
}

.admin-info {
    text-align: right;
}

.admin-info strong {
    display: block;
    font-size: 13px;
}

.admin-info span {
    font-size: 11px;
    color: #94a3b8;
}

.admin-avatar {
    width: 40px;
    height: 40px;
    flex-shrink: 0;
    border-radius: 50%;
    background: linear-gradient(135deg, #2563eb, #7c3aed);
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
}

/* CONTENT */
.content {
    padding: 30px 35px;
}

.header-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 25px;
}

.header-content h1 {
    font-size: 25px;
    color: #0f172a;
}

.header-content p {
    color: #64748b;
    font-size: 13px;
    margin-top: 5px;
}

/* INFO */
.info-box {
    background: white;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    padding: 18px 20px;
    margin-bottom: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 15px;
}

.info-box strong {
    color: #2563eb;
    font-size: 20px;
}

.info-box span {
    display: block;
    color: #64748b;
    font-size: 12px;
    margin-top: 3px;
}

.info-box .tanggal-cetak {
    font-size: 14px;
    color: #0f172a;
}

/* CARD */
.card {
    background: white;
    border: 1px solid #e2e8f0;
    border-radius: 15px;
    overflow: hidden;
    box-shadow: 0 5px 20px rgba(15,23,42,.03);
}

.card-header {
    padding: 20px;
    border-bottom: 1px solid #e2e8f0;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 15px;
}

.card-header h3 {
    font-size: 16px;
}

/* BUTTON */
.btn-cetak {
    background: linear-gradient(135deg, #2563eb, #4f46e5);
    color: white;
    border: none;
    padding: 10px 15px;
    border-radius: 8px;
    text-decoration: none;
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
}

.btn-cetak:hover {
    background: #1d4ed8;
}

/* TABLE */
.table-container {
    width: 100%;
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th {
    text-align: left;
    padding: 14px 12px;
    background: #f8fafc;
    color: #64748b;
    font-size: 11px;
    text-transform: uppercase;
    white-space: nowrap;
}

td {
    padding: 14px 12px;
    border-top: 1px solid #f1f5f9;
    font-size: 12px;
    vertical-align: middle;
    overflow-wrap: anywhere;
}

tbody tr:hover {
    background: #f8fafc;
}

/* STATUS */
.badge {
    display: inline-block;
    padding: 6px 10px;
    border-radius: 20px;
    font-size: 10px;
    font-weight: 600;
    white-space: nowrap;
}

.menunggu {
    background: #fef3c7;
    color: #92400e;
}

.disetujui {
    background: #dbeafe;
    color: #1d4ed8;
}

.ditolak {
    background: #fee2e2;
    color: #b91c1c;
}

.selesai {
    background: #dcfce7;
    color: #166534;
}

/* EMPTY */
.empty {
    text-align: center;
    padding: 50px 20px;
    color: #94a3b8;
}

/* =========================
   PRINT A4 LANDSCAPE
========================= */
@media print {
    @page {
        size: A4 landscape;
        margin: 8mm;
    }

    * {
        box-sizing: border-box !important;
        -webkit-print-color-adjust: exact;
        print-color-adjust: exact;
    }

    body {
        background: #fff !important;
        color: #000 !important;
        margin: 0 !important;
        padding: 0 !important;
        font-size: 9px !important;
    }

    .sidebar,
    .topbar,
    .btn-cetak,
    .logout {
        display: none !important;
    }

    .main {
        width: 100% !important;
        margin: 0 !important;
        min-height: auto !important;
    }

    .content {
        width: 100% !important;
        padding: 0 !important;
        margin: 0 !important;
    }

    .header-content {
        display: block !important;
        margin-bottom: 10px !important;
    }

    .header-content h1 {
        font-size: 18px !important;
        color: #000 !important;
    }

    .header-content p {
        font-size: 10px !important;
        color: #333 !important;
    }

    .info-box {
        padding: 7px 10px !important;
        margin-bottom: 10px !important;
        background: #fff !important;
        border: 1px solid #aaa !important;
        border-radius: 0 !important;
        break-inside: avoid;
    }

    .info-box strong {
        font-size: 14px !important;
    }

    .info-box span {
        font-size: 9px !important;
        color: #333 !important;
    }

    .info-box .tanggal-cetak {
        font-size: 11px !important;
    }

    .card {
        width: 100% !important;
        overflow: visible !important;
        border: none !important;
        border-radius: 0 !important;
        box-shadow: none !important;
    }

    .card-header {
        padding: 7px 0 !important;
        border-bottom: 1px solid #777 !important;
    }

    .card-header h3 {
        font-size: 12px !important;
        color: #000 !important;
    }

    .table-container {
        width: 100% !important;
        overflow: visible !important;
    }

    table {
        width: 100% !important;
        table-layout: fixed !important;
        border-collapse: collapse !important;
        font-size: 8px !important;
    }

    th,
    td {
        padding: 5px 4px !important;
        border: 1px solid #777 !important;
        color: #000 !important;
        font-size: 8px !important;
        text-align: left;
        vertical-align: top !important;
        white-space: normal !important;
        overflow-wrap: break-word !important;
        word-break: normal !important;
    }

    th {
        background: #e5e7eb !important;
        font-weight: bold !important;
    }

    th:nth-child(1),
    td:nth-child(1) {
        width: 4% !important;
        text-align: center !important;
    }

    th:nth-child(2),
    td:nth-child(2) {
        width: 13% !important;
    }

    th:nth-child(3),
    td:nth-child(3) {
        width: 13% !important;
    }

    th:nth-child(4),
    td:nth-child(4) {
        width: 8% !important;
    }

    th:nth-child(5),
    td:nth-child(5) {
        width: 13% !important;
    }

    th:nth-child(6),
    td:nth-child(6) {
        width: 14% !important;
    }

    th:nth-child(7),
    td:nth-child(7) {
        width: 23% !important;
    }

    th:nth-child(8),
    td:nth-child(8) {
        width: 12% !important;
    }

    thead {
        display: table-header-group;
    }

    tr {
        break-inside: avoid !important;
        page-break-inside: avoid !important;
    }

    tbody tr:hover {
        background: #fff !important;
    }

    .badge {
        display: inline !important;
        padding: 0 !important;
        border: none !important;
        background: transparent !important;
        color: #000 !important;
        font-size: 8px !important;
        font-weight: bold !important;
        white-space: normal !important;
    }

    .empty {
        text-align: center !important;
        padding: 12px !important;
    }
}

/* RESPONSIVE */
@media (max-width: 800px) {
    .sidebar {
        width: 70px;
        padding: 20px 10px;
    }

    .logo-text,
    .menu-title,
    .menu a span {
        display: none;
    }

    .logo {
        justify-content: center;
    }

    .menu a {
        justify-content: center;
    }

    .logout {
        left: 10px;
        right: 10px;
    }

    .logout a {
        justify-content: center;
    }

    .main {
        margin-left: 70px;
    }

    .content {
        padding: 20px 15px;
    }

    .topbar {
        padding: 15px;
    }

    .admin-info {
        display: none;
    }
}
</style>
</head>

<body>

<!-- SIDEBAR -->
<aside class="sidebar">
    <div class="logo">
        <div class="logo-icon">🏘️</div>
        <div class="logo-text">
            <h2>Karang Taruna</h2>
            <span>Sistem Informasi</span>
        </div>
    </div>

    <div class="menu-title">Menu Utama</div>

    <nav class="menu">
        <a href="../dashboard.php">
            <div class="menu-icon">🏠</div>
            <span>Dashboard</span>
        </a>

        <a href="../anggota/index.php">
            <div class="menu-icon">👥</div>
            <span>Data Anggota</span>
        </a>

        <a href="../alat/index.php">
            <div class="menu-icon">📦</div>
            <span>Data Alat</span>
        </a>

        <a href="../peminjaman/index.php">
            <div class="menu-icon">📋</div>
            <span>Peminjaman</span>
        </a>

        <a href="../pengembalian/index.php">
            <div class="menu-icon">🔄</div>
            <span>Pengembalian</span>
        </a>

        <a href="peminjaman.php" class="active">
            <div class="menu-icon">📊</div>
            <span>Laporan</span>
        </a>
    </nav>

    <div class="logout">
        <a href="../logout.php">
            <div class="menu-icon">🚪</div>
            <span>Logout</span>
        </a>
    </div>
</aside>

<!-- MAIN -->
<main class="main">

    <!-- TOPBAR -->
    <header class="topbar">
        <div class="page-title">
            <h2>Laporan Peminjaman</h2>
            <p>Laporan data peminjaman alat Karang Taruna</p>
        </div>

        <div class="admin">
            <div class="admin-info">
                <strong><?= e($_SESSION['username'] ?? 'Admin') ?></strong>
                <span>Admin</span>
            </div>

            <div class="admin-avatar">
                <?= e(strtoupper(substr($_SESSION['username'] ?? 'A', 0, 1))) ?>
            </div>
        </div>
    </header>

    <!-- CONTENT -->
    <section class="content">

        <div class="header-content">
            <div>
                <h1>📊 Laporan Peminjaman</h1>
                <p>Rekap seluruh data peminjaman alat</p>
            </div>
        </div>

        <!-- INFO -->
        <div class="info-box">
            <div>
                <strong><?= $total ?></strong>
                <span>Total Data Peminjaman</span>
            </div>

            <div>
                <span>Dicetak pada:</span>
                <strong class="tanggal-cetak">
                    <?= date('d-m-Y H:i') ?>
                </strong>
            </div>
        </div>

        <!-- TABLE CARD -->
        <div class="card">

            <div class="card-header">
                <h3>Data Peminjaman</h3>

                <button
                    type="button"
                    class="btn-cetak"
                    onclick="window.print()"
                >
                    🖨️ Cetak Laporan
                </button>
            </div>

            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Peminjam</th>
                            <th>Alat</th>
                            <th>Jumlah</th>
                            <th>Tanggal Pinjam</th>
                            <th>Rencana Kembali</th>
                            <th>Keperluan</th>
                            <th>Status</th>
                        </tr>
                    </thead>

                    <tbody>
                    <?php
                    $no = 1;

                    if ($total > 0):
                        while ($row = mysqli_fetch_assoc($query)):
                            $status = $row['status'] ?? '-';

                            $classStatus = strtolower(trim($status));
                            $classStatus = preg_replace(
                                '/[^a-z0-9-]/',
                                '',
                                $classStatus
                            );
                    ?>
                        <tr>
                            <td><?= $no++ ?></td>

                            <td>
                                <strong>
                                    <?= e($row['nama_peminjam'] ?? '-') ?>
                                </strong>
                            </td>

                            <td>
                                <?= e($row['nama_alat'] ?? '-') ?>
                            </td>

                            <td>
                                <?= e($row['jumlah_pinjam'] ?? '0') ?> unit
                            </td>

                            <td>
                                <?= e(tanggalIndonesia($row['tanggal_pinjam'] ?? null)) ?>
                            </td>

                            <td>
                                <?= e(tanggalIndonesia($row['tanggal_kembali'] ?? null)) ?>
                            </td>

                            <td>
                                <?= e($row['keperluan'] ?? '-') ?>
                            </td>

                            <td>
                                <span class="badge <?= e($classStatus) ?>">
                                    <?= e($status) ?>
                                </span>
                            </td>
                        </tr>
                    <?php
                        endwhile;
                    else:
                    ?>
                        <tr>
                            <td colspan="8" class="empty">
                                Belum ada data peminjaman.
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </section>
</main>

</body>
</html>
