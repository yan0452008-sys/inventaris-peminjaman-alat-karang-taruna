<?php

session_start();

if (!isset($_SESSION['login'])) {
    header("Location: ../login.php");
    exit;
}

include "../koneksi.php";


// =========================
// CEK ID
// =========================

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$id = (int) $_GET['id'];


// =========================
// MULAI TRANSAKSI
// =========================

mysqli_begin_transaction($conn);

try {

    // =========================
    // AMBIL DATA PEMINJAMAN
    // =========================

    $cek = mysqli_query(
        $conn,
        "
        SELECT 
            id_peminjaman,
            status
        FROM peminjaman
        WHERE id_peminjaman = $id
        FOR UPDATE
        "
    );


    if (!$cek) {
        throw new Exception(
            "Gagal mengambil data peminjaman: "
            . mysqli_error($conn)
        );
    }


    // =========================
    // CEK DATA
    // =========================

    if (mysqli_num_rows($cek) == 0) {
        throw new Exception(
            "Data peminjaman tidak ditemukan."
        );
    }


    $data = mysqli_fetch_assoc($cek);

    $status = $data['status'];


    // =========================
    // STATUS DISETUJUI
    // =========================
    /*
     * Jika masih Disetujui,
     * alat masih dianggap sedang dipinjam.
     *
     * Jadi tidak boleh dihapus.
     */

    if ($status == 'Disetujui') {

        throw new Exception(
            "Peminjaman yang masih Disetujui tidak dapat dihapus. Silakan proses Pengembalian terlebih dahulu."
        );
    }


    // =========================
    // HAPUS DATA
    // =========================
    /*
     * Yang boleh dihapus:
     *
     * Menunggu
     * Ditolak
     * Selesai
     */

    $hapus = mysqli_query(
        $conn,
        "
        DELETE FROM peminjaman
        WHERE id_peminjaman = $id
        "
    );


    if (!$hapus) {

        throw new Exception(
            "Data peminjaman gagal dihapus: "
            . mysqli_error($conn)
        );
    }


    // =========================
    // SIMPAN TRANSAKSI
    // =========================

    mysqli_commit($conn);


    // =========================
    // BERHASIL
    // =========================

    echo "
    <script>
        alert('Data peminjaman berhasil dihapus!');
        window.location='index.php';
    </script>
    ";

    exit;


} catch (Exception $e) {


    // =========================
    // BATALKAN TRANSAKSI
    // =========================

    mysqli_rollback($conn);


    $pesan = json_encode(
        "Data tidak dapat dihapus: "
        . $e->getMessage()
    );


    echo "
    <script>
        alert($pesan);
        window.location='index.php';
    </script>
    ";

    exit;
}

?>