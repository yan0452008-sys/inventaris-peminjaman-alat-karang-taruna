<?php

session_start();

if (!isset($_SESSION['login'])) {
    header("Location: ../login.php");
    exit;
}

include "../koneksi.php";


/* =========================
   CEK DATA
========================= */

if (
    !isset($_GET['id']) ||
    !isset($_GET['status'])
) {

    header("Location: index.php");
    exit;

}


$id = (int) $_GET['id'];

$status = $_GET['status'];


/* =========================
   STATUS YANG DIIZINKAN
========================= */

$status_valid = [
    'Disetujui',
    'Ditolak'
];


if (!in_array($status, $status_valid)) {

    echo "
    <script>
        alert('Status tidak valid!');
        window.location='index.php';
    </script>
    ";

    exit;
}


/* =========================
   MULAI TRANSAKSI
========================= */

mysqli_begin_transaction($conn);


try {


    /* =========================
       AMBIL DATA PEMINJAMAN
    ========================= */

    $query = mysqli_query(
        $conn,
        "
        SELECT
            id_peminjaman,
            id_alat,
            jumlah_pinjam,
            status
        FROM peminjaman
        WHERE id_peminjaman = $id
        FOR UPDATE
        "
    );


    if (!$query) {

        throw new Exception(
            mysqli_error($conn)
        );

    }


    /* =========================
       CEK DATA
    ========================= */

    if (mysqli_num_rows($query) == 0) {

        throw new Exception(
            "Data peminjaman tidak ditemukan."
        );

    }


    $data = mysqli_fetch_assoc($query);


    $status_lama =
        $data['status'];

    $id_alat =
        (int) $data['id_alat'];

    $jumlah_pinjam =
        (int) $data['jumlah_pinjam'];


    /* =========================
       JIKA DISETUJUI
    ========================= */

    if ($status == 'Disetujui') {


        /* =========================
           HANYA BOLEH DARI MENUNGGU
        ========================= */

        if ($status_lama != 'Menunggu') {

            throw new Exception(
                "Peminjaman ini sudah diproses sebelumnya."
            );

        }


        /* =========================
           CEK STOK ALAT
        ========================= */

        $cek_alat = mysqli_query(
            $conn,
            "
            SELECT
                jumlah,
                kondisi
            FROM alat
            WHERE id_alat = $id_alat
            FOR UPDATE
            "
        );


        if (!$cek_alat) {

            throw new Exception(
                mysqli_error($conn)
            );

        }


        if (mysqli_num_rows($cek_alat) == 0) {

            throw new Exception(
                "Data alat tidak ditemukan."
            );

        }


        $alat =
            mysqli_fetch_assoc($cek_alat);


        $stok =
            (int) $alat['jumlah'];


        $kondisi =
            $alat['kondisi'];


        /* =========================
           CEK KONDISI ALAT
        ========================= */

        if ($kondisi == 'Rusak Berat') {

            throw new Exception(
                "Alat dalam kondisi rusak berat dan tidak dapat dipinjam."
            );

        }


        /* =========================
           CEK STOK
        ========================= */

        if ($jumlah_pinjam <= 0) {

            throw new Exception(
                "Jumlah peminjaman tidak valid."
            );

        }


        if ($jumlah_pinjam > $stok) {

            throw new Exception(
                "Stok alat tidak mencukupi. " .
                "Stok tersedia: " .
                $stok .
                " unit."
            );

        }


        /* =========================
           KURANGI STOK
        ========================= */

        $update_alat = mysqli_query(
            $conn,
            "
            UPDATE alat
            SET jumlah = jumlah - $jumlah_pinjam
            WHERE id_alat = $id_alat
            "
        );


        if (!$update_alat) {

            throw new Exception(
                mysqli_error($conn)
            );

        }


        /* =========================
           UBAH STATUS
        ========================= */

        $update_status = mysqli_query(
            $conn,
            "
            UPDATE peminjaman
            SET status = 'Disetujui'
            WHERE id_peminjaman = $id
            "
        );


        if (!$update_status) {

            throw new Exception(
                mysqli_error($conn)
            );

        }

    }


    /* =========================
       JIKA DITOLAK
    ========================= */

    elseif ($status == 'Ditolak') {


        /* =========================
           HANYA BOLEH DARI MENUNGGU
        ========================= */

        if ($status_lama != 'Menunggu') {

            throw new Exception(
                "Peminjaman ini sudah diproses sebelumnya."
            );

        }


        /* =========================
           UBAH STATUS
        ========================= */

        $update_status = mysqli_query(
            $conn,
            "
            UPDATE peminjaman
            SET status = 'Ditolak'
            WHERE id_peminjaman = $id
            "
        );


        if (!$update_status) {

            throw new Exception(
                mysqli_error($conn)
            );

        }

    }


    /* =========================
       SIMPAN TRANSAKSI
    ========================= */

    mysqli_commit($conn);


    /* =========================
       PESAN BERHASIL
    ========================= */

    if ($status == 'Disetujui') {

        $pesan =
            "Peminjaman disetujui dan stok alat berhasil dikurangi.";

    } else {

        $pesan =
            "Peminjaman berhasil ditolak.";

    }


    echo "
    <script>

        alert(
            " . json_encode($pesan) . "
        );

        window.location='index.php';

    </script>
    ";

    exit;


} catch (Exception $e) {


    /* =========================
       BATALKAN TRANSAKSI
    ========================= */

    mysqli_rollback($conn);


    echo "
    <script>

        alert(
            " . json_encode(
                "Gagal memproses peminjaman: " .
                $e->getMessage()
            ) . "
        );

        window.location='index.php';

    </script>
    ";

    exit;

}

?>
