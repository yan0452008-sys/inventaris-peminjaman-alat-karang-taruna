<?php

session_start();

if (!isset($_SESSION['login'])) {
    header("Location: ../login.php");
    exit;
}

include "../koneksi.php";

if (isset($_POST['simpan'])) {

    $nama_peminjam  = trim($_POST['nama_peminjam']);
    $id_alat        = (int) $_POST['id_alat'];
    $jumlah_pinjam  = (int) $_POST['jumlah_pinjam'];
    $tanggal_pinjam = $_POST['tanggal_pinjam'];
    $tanggal_kembali = $_POST['tanggal_kembali'];
    $keperluan      = trim($_POST['keperluan']);

    // Validasi nama
    if ($nama_peminjam == '') {
        echo "<script>
            alert('Nama peminjam wajib diisi!');
            history.back();
        </script>";
        exit;
    }

    // Validasi alat
    if ($id_alat <= 0) {
        echo "<script>
            alert('Silakan pilih alat!');
            history.back();
        </script>";
        exit;
    }

    // Validasi jumlah
    if ($jumlah_pinjam <= 0) {
        echo "<script>
            alert('Jumlah peminjaman harus lebih dari 0!');
            history.back();
        </script>";
        exit;
    }

    // Validasi tanggal
    if ($tanggal_pinjam == '' || $tanggal_kembali == '') {
        echo "<script>
            alert('Tanggal pinjam dan tanggal kembali wajib diisi!');
            history.back();
        </script>";
        exit;
    }

    if ($tanggal_kembali < $tanggal_pinjam) {
        echo "<script>
            alert('Tanggal kembali tidak boleh sebelum tanggal pinjam!');
            history.back();
        </script>";
        exit;
    }

    // Mulai transaksi
    mysqli_begin_transaction($conn);

    try {

        // Ambil data alat dan kunci baris
        $cek_alat = mysqli_query(
            $conn,
            "
            SELECT id_alat, nama_alat, jumlah, kondisi
            FROM alat
            WHERE id_alat = $id_alat
            FOR UPDATE
            "
        );

        if (!$cek_alat) {
            throw new Exception(
                "Gagal mengambil data alat: " . mysqli_error($conn)
            );
        }

        // Cek alat ditemukan
        if (mysqli_num_rows($cek_alat) == 0) {
            throw new Exception(
                "Alat tidak ditemukan."
            );
        }

        $alat = mysqli_fetch_assoc($cek_alat);

        $nama_alat = $alat['nama_alat'];
        $stok      = (int) $alat['jumlah'];
        $kondisi   = $alat['kondisi'];

        // Cek kondisi alat
        if ($kondisi == 'Rusak Berat') {
            throw new Exception(
                "Alat " . $nama_alat . " dalam kondisi Rusak Berat dan tidak dapat dipinjam."
            );
        }

        // Cek stok
        if ($stok <= 0) {
            throw new Exception(
                "Stok alat " . $nama_alat . " sedang habis."
            );
        }

        // Cek jumlah pinjam
        if ($jumlah_pinjam > $stok) {
            throw new Exception(
                "Jumlah yang dipinjam melebihi stok tersedia. Stok saat ini: " . $stok
            );
        }

        /*
         * SIMPAN PEMINJAMAN
         *
         * Status awal = Menunggu
         *
         * Stok TIDAK dikurangi di sini.
         * Stok baru dikurangi ketika peminjaman disetujui
         * melalui status.php
         */

        $query = mysqli_query(
            $conn,
            "
            INSERT INTO peminjaman
            (
                nama_peminjam,
                id_alat,
                jumlah_pinjam,
                tanggal_pinjam,
                tanggal_kembali,
                keperluan,
                status
            )
            VALUES
            (
                '$nama_peminjam',
                $id_alat,
                $jumlah_pinjam,
                '$tanggal_pinjam',
                '$tanggal_kembali',
                '$keperluan',
                'Menunggu'
            )
            "
        );

        if (!$query) {
            throw new Exception(
                "Data peminjaman gagal disimpan: " . mysqli_error($conn)
            );
        }

        // Simpan transaksi
        mysqli_commit($conn);

        echo "<script>
            alert('Data peminjaman berhasil ditambahkan dan menunggu persetujuan!');
            window.location='index.php';
        </script>";

        exit;

    } catch (Exception $e) {

        // Batalkan transaksi
        mysqli_rollback($conn);

        $pesan = json_encode(
            $e->getMessage()
        );

        echo "<script>
            alert($pesan);
            history.back();
        </script>";

        exit;
    }
}


// Ambil data alat untuk ditampilkan di form
$alat = mysqli_query(
    $conn,
    "
    SELECT id_alat, nama_alat, jumlah, kondisi
    FROM alat
    ORDER BY nama_alat ASC
    "
);

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Tambah Peminjaman</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f7fb;
            color: #333;
        }

        .container {
            width: 700px;
            max-width: 95%;
            margin: 40px auto;
        }

        .card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.08);
        }

        h2 {
            margin-top: 0;
            margin-bottom: 25px;
            color: #243b7a;
        }

        .form-group {
            margin-bottom: 18px;
        }

        label {
            display: block;
            margin-bottom: 7px;
            font-weight: bold;
            color: #333;
        }

        input,
        select,
        textarea {
            width: 100%;
            padding: 11px 13px;
            border: 1px solid #d5dbea;
            border-radius: 8px;
            font-size: 14px;
            outline: none;
        }

        input:focus,
        select:focus,
        textarea:focus {
            border-color: #4267b2;
        }

        textarea {
            resize: vertical;
            min-height: 100px;
        }

        .info {
            margin-top: 8px;
            padding: 10px;
            background: #eef4ff;
            border-radius: 8px;
            color: #345;
            font-size: 13px;
        }

        .warning {
            display: none;
            margin-top: 8px;
            padding: 10px;
            background: #fff0f0;
            color: #b42318;
            border-radius: 8px;
            font-size: 13px;
        }

        .button-group {
            display: flex;
            gap: 10px;
            margin-top: 25px;
        }

        button,
        .btn-kembali {
            border: none;
            padding: 11px 20px;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
        }

        .btn-simpan {
            background: #3158a8;
            color: white;
        }

        .btn-simpan:hover {
            background: #26498f;
        }

        .btn-kembali {
            background: #e5e7eb;
            color: #333;
        }

        .btn-kembali:hover {
            background: #d1d5db;
        }

        .status-info {
            background: #fff8e1;
            color: #795600;
            padding: 12px;
            border-radius: 8px;
            font-size: 13px;
            margin-bottom: 20px;
        }

    </style>

</head>

<body>

<div class="container">

    <div class="card">

        <h2>Tambah Data Peminjaman</h2>

        <div class="status-info">
            Status awal peminjaman adalah <b>Menunggu</b>.
            Stok alat baru akan berkurang setelah peminjaman disetujui.
        </div>

        <form method="POST" onsubmit="return validasiForm();">

            <div class="form-group">

                <label>Nama Peminjam</label>

                <input
                    type="text"
                    name="nama_peminjam"
                    placeholder="Masukkan nama peminjam"
                    required
                >

            </div>


            <div class="form-group">

                <label>Alat</label>

                <select
                    name="id_alat"
                    id="id_alat"
                    onchange="cekAlat()"
                    required
                >

                    <option value="">-- Pilih Alat --</option>

                    <?php while ($row = mysqli_fetch_assoc($alat)) { ?>

                        <option
                            value="<?= $row['id_alat']; ?>"
                            data-stok="<?= $row['jumlah']; ?>"
                            data-kondisi="<?= htmlspecialchars($row['kondisi']); ?>"
                        >

                            <?= htmlspecialchars($row['nama_alat']); ?>

                            - Stok: <?= $row['jumlah']; ?>

                        </option>

                    <?php } ?>

                </select>

                <div id="infoStok" class="info" style="display:none;"></div>

                <div id="warningAlat" class="warning"></div>

            </div>


            <div class="form-group">

                <label>Jumlah Pinjam</label>

                <input
                    type="number"
                    name="jumlah_pinjam"
                    id="jumlah_pinjam"
                    min="1"
                    value="1"
                    required
                >

            </div>


            <div class="form-group">

                <label>Tanggal Pinjam</label>

                <input
                    type="date"
                    name="tanggal_pinjam"
                    id="tanggal_pinjam"
                    required
                >

            </div>


            <div class="form-group">

                <label>Tanggal Kembali</label>

                <input
                    type="date"
                    name="tanggal_kembali"
                    id="tanggal_kembali"
                    required
                >

            </div>


            <div class="form-group">

                <label>Keperluan</label>

                <textarea
                    name="keperluan"
                    placeholder="Masukkan keperluan peminjaman"
                    required
                ></textarea>

            </div>


            <div class="button-group">

                <button
                    type="submit"
                    name="simpan"
                    class="btn-simpan"
                >
                    Simpan Peminjaman
                </button>

                <a
                    href="index.php"
                    class="btn-kembali"
                >
                    Kembali
                </a>

            </div>

        </form>

    </div>

</div>


<script>

    // Set tanggal hari ini
    const hariIni = new Date();

    const tahun = hariIni.getFullYear();

    const bulan = String(
        hariIni.getMonth() + 1
    ).padStart(2, '0');

    const tanggal = String(
        hariIni.getDate()
    ).padStart(2, '0');

    const tanggalHariIni =
        tahun + '-' + bulan + '-' + tanggal;


    document.getElementById(
        'tanggal_pinjam'
    ).value = tanggalHariIni;


    document.getElementById(
        'tanggal_kembali'
    ).min = tanggalHariIni;


    // Ketika tanggal pinjam berubah
    document.getElementById(
        'tanggal_pinjam'
    ).addEventListener(
        'change',
        function () {

            document.getElementById(
                'tanggal_kembali'
            ).min = this.value;

            if (
                document.getElementById(
                    'tanggal_kembali'
                ).value < this.value
            ) {

                document.getElementById(
                    'tanggal_kembali'
                ).value = this.value;

            }

        }
    );


    // Cek alat yang dipilih
    function cekAlat() {

        const select =
            document.getElementById('id_alat');

        const option =
            select.options[select.selectedIndex];

        const info =
            document.getElementById('infoStok');

        const warning =
            document.getElementById('warningAlat');

        const jumlah =
            document.getElementById('jumlah_pinjam');


        if (!select.value) {

            info.style.display = 'none';

            warning.style.display = 'none';

            jumlah.max = '';

            return;
        }


        const stok =
            parseInt(option.dataset.stok);

        const kondisi =
            option.dataset.kondisi;


        info.style.display = 'block';

        info.innerHTML =
            'Stok tersedia: <b>' + stok + '</b>';


        jumlah.max = stok;


        if (kondisi === 'Rusak Berat') {

            warning.style.display = 'block';

            warning.innerHTML =
                'Alat ini dalam kondisi <b>Rusak Berat</b> dan tidak dapat dipinjam.';

        }

        else if (stok <= 0) {

            warning.style.display = 'block';

            warning.innerHTML =
                'Stok alat sedang habis.';

        }

        else {

            warning.style.display = 'none';

        }


        // Jika jumlah melebihi stok
        if (parseInt(jumlah.value) > stok) {

            jumlah.value = stok;

        }

    }


    // Validasi sebelum submit
    function validasiForm() {

        const select =
            document.getElementById('id_alat');

        const option =
            select.options[select.selectedIndex];

        const jumlah =
            parseInt(
                document.getElementById(
                    'jumlah_pinjam'
                ).value
            );


        if (!select.value) {

            alert('Silakan pilih alat terlebih dahulu!');

            return false;

        }


        const stok =
            parseInt(option.dataset.stok);

        const kondisi =
            option.dataset.kondisi;


        if (kondisi === 'Rusak Berat') {

            alert(
                'Alat dalam kondisi Rusak Berat dan tidak dapat dipinjam!'
            );

            return false;

        }


        if (stok <= 0) {

            alert(
                'Stok alat sedang habis!'
            );

            return false;

        }


        if (jumlah <= 0) {

            alert(
                'Jumlah peminjaman harus lebih dari 0!'
            );

            return false;

        }


        if (jumlah > stok) {

            alert(
                'Jumlah peminjaman melebihi stok tersedia!'
            );

            return false;

        }


        return true;

    }

</script>

</body>

</html>