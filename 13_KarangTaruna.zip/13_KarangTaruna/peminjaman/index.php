<?php

session_start();

if (!isset($_SESSION['login'])) {
    header("Location: ../login.php");
    exit;
}

include "../koneksi.php";


/* =========================
   AMBIL DATA PEMINJAMAN
========================= */

$query = mysqli_query($conn, "
    SELECT 
        p.*,
        al.nama_alat
    FROM peminjaman p
    LEFT JOIN alat al
        ON p.id_alat = al.id_alat
    ORDER BY p.id_peminjaman DESC
");

if (!$query) {
    die(
        "Gagal mengambil data peminjaman: "
        . mysqli_error($conn)
    );
}

?>

<!DOCTYPE html>

<html lang="id">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>
    Peminjaman | Karang Taruna
</title>


<style>

/* =========================
   RESET
========================= */

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family:
        "Segoe UI",
        Arial,
        sans-serif;
}

body {
    background: #f1f5f9;
    color: #1e293b;
}


/* =========================
   SIDEBAR
========================= */

.sidebar {
    position: fixed;
    left: 0;
    top: 0;
    width: 250px;
    height: 100vh;

    background:
        linear-gradient(
            180deg,
            #1e3a8a,
            #312e81
        );

    color: white;
    padding: 25px 18px;
    z-index: 1000;
}

.logo {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 10px;
    margin-bottom: 35px;
}

.logo-icon {
    width: 45px;
    height: 45px;
    border-radius: 12px;

    background:
        rgba(255,255,255,.15);

    display: flex;
    align-items: center;
    justify-content: center;

    font-size: 23px;
}

.logo-text h2 {
    font-size: 17px;
}

.logo-text span {
    font-size: 11px;
    color: #c7d2fe;
}


/* MENU */

.menu-title {
    font-size: 11px;
    color: #a5b4fc;

    margin:
        20px 12px 10px;

    text-transform: uppercase;
    letter-spacing: 1px;
}

.menu a {
    display: flex;
    align-items: center;
    gap: 13px;

    color: #e0e7ff;
    text-decoration: none;

    padding: 12px 14px;
    margin: 5px 0;

    border-radius: 10px;
    font-size: 14px;

    transition: .3s;
}

.menu a:hover,
.menu a.active {
    background:
        rgba(255,255,255,.14);

    color: white;
}

.menu-icon {
    width: 25px;
    text-align: center;
    font-size: 17px;
}


/* LOGOUT */

.logout {
    position: absolute;
    bottom: 25px;
    left: 18px;
    right: 18px;
}

.logout a {
    display: flex;
    align-items: center;
    gap: 13px;

    color: #fecaca;
    text-decoration: none;

    padding: 12px 14px;
    border-radius: 10px;

    background:
        rgba(239,68,68,.15);

    transition: .3s;
}

.logout a:hover {
    background:
        rgba(239,68,68,.25);
}


/* =========================
   MAIN
========================= */

.main {
    margin-left: 250px;
    min-height: 100vh;
}


/* TOPBAR */

.topbar {
    height: 75px;
    background: white;

    display: flex;
    align-items: center;
    justify-content: space-between;

    padding: 0 35px;

    border-bottom:
        1px solid #e2e8f0;
}

.page-title h2 {
    font-size: 20px;
    color: #0f172a;
}

.page-title p {
    font-size: 12px;
    color: #94a3b8;
    margin-top: 3px;
}


/* ADMIN */

.admin {
    display: flex;
    align-items: center;
    gap: 12px;
}

.admin-info {
    text-align: right;
}

.admin-info strong {
    display: block;
    font-size: 13px;
}

.admin-info span {
    font-size: 11px;
    color: #94a3b8;
}

.admin-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;

    background:
        linear-gradient(
            135deg,
            #2563eb,
            #7c3aed
        );

    color: white;

    display: flex;
    align-items: center;
    justify-content: center;

    font-weight: bold;
}


/* =========================
   CONTENT
========================= */

.content {
    padding: 30px 35px;
}

.header-content {
    display: flex;
    justify-content: space-between;
    align-items: center;

    margin-bottom: 25px;
}

.header-content h1 {
    font-size: 25px;
    color: #0f172a;
}

.header-content p {
    color: #64748b;
    font-size: 13px;
    margin-top: 5px;
}


/* TOMBOL TAMBAH */

.btn-tambah {
    background:
        linear-gradient(
            135deg,
            #2563eb,
            #4f46e5
        );

    color: white;
    text-decoration: none;

    padding: 12px 18px;

    border-radius: 10px;

    font-size: 13px;
    font-weight: 600;

    transition: .3s;
}

.btn-tambah:hover {
    transform: translateY(-2px);

    box-shadow:
        0 8px 20px
        rgba(37,99,235,.25);
}


/* =========================
   CARD
========================= */

.card {
    background: white;

    border:
        1px solid #e2e8f0;

    border-radius: 15px;

    overflow: hidden;

    box-shadow:
        0 5px 20px
        rgba(15,23,42,.03);
}

.card-header {
    padding: 20px;

    border-bottom:
        1px solid #e2e8f0;

    display: flex;
    align-items: center;
    justify-content: space-between;
}

.card-header h3 {
    font-size: 16px;
}


/* =========================
   TABLE
========================= */

.table-container {
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th {
    text-align: left;

    padding: 14px 20px;

    background: #f8fafc;

    color: #64748b;

    font-size: 11px;

    text-transform: uppercase;

    white-space: nowrap;
}

td {
    padding: 15px 20px;

    border-top:
        1px solid #f1f5f9;

    font-size: 13px;

    vertical-align: middle;
}

tr:hover {
    background: #f8fafc;
}


/* =========================
   PEMINJAM
========================= */

.nama-peminjam {
    font-weight: 600;
    color: #0f172a;
}


/* =========================
   BADGE STATUS
========================= */

.badge {
    display: inline-block;

    padding: 6px 11px;

    border-radius: 20px;

    font-size: 10px;

    font-weight: 600;

    white-space: nowrap;
}

.menunggu {
    background: #fef3c7;
    color: #92400e;
}

.disetujui {
    background: #dbeafe;
    color: #1d4ed8;
}

.ditolak {
    background: #fee2e2;
    color: #b91c1c;
}

.selesai {
    background: #dcfce7;
    color: #166534;
}


/* =========================
   BUTTON
========================= */

.btn {
    display: inline-block;

    padding: 7px 10px;

    border-radius: 7px;

    text-decoration: none;

    font-size: 11px;

    font-weight: 600;

    margin: 2px;

    border: none;

    transition: .2s;

    white-space: nowrap;
}

.btn:hover {
    opacity: .8;
    transform: translateY(-1px);
}


/* EDIT */

.btn-edit {
    background: #dbeafe;
    color: #1d4ed8;
}


/* HAPUS */

.btn-hapus {
    background: #fee2e2;
    color: #b91c1c;
}


/* SETUJUI */

.btn-setujui {
    background: #dcfce7;
    color: #166534;
}


/* TOLAK */

.btn-tolak {
    background: #fee2e2;
    color: #b91c1c;
}


/* PENGEMBALIAN */

.btn-selesai {
    background: #e0e7ff;
    color: #4338ca;
}


/* =========================
   ACTION BOX
========================= */

.action-box {
    display: flex;
    flex-wrap: wrap;
    gap: 2px;
    min-width: 180px;
}


/* =========================
   EMPTY
========================= */

.empty {
    text-align: center;
    padding: 55px;
    color: #94a3b8;
}

.empty-icon {
    font-size: 40px;
    margin-bottom: 10px;
}


/* =========================
   RESPONSIVE
========================= */

@media(max-width:1100px) {

    .content {
        padding: 25px;
    }

}

@media(max-width:800px) {

    .sidebar {
        width: 70px;
        padding: 20px 10px;
    }

    .logo-text,
    .menu-title,
    .menu a span {
        display: none;
    }

    .logo {
        justify-content: center;
    }

    .menu a {
        justify-content: center;
    }

    .logout {
        left: 10px;
        right: 10px;
    }

    .logout a {
        justify-content: center;
    }

    .main {
        margin-left: 70px;
    }

    .content {
        padding: 20px 15px;
    }

    .topbar {
        padding: 0 15px;
    }

    .admin-info {
        display: none;
    }

    .header-content {
        align-items: flex-start;
        gap: 15px;
        flex-direction: column;
    }

    .btn-tambah {
        width: 100%;
        text-align: center;
    }

}

</style>

</head>


<body>


<!-- =========================
     SIDEBAR
========================= -->

<aside class="sidebar">

    <div class="logo">

        <div class="logo-icon">
            🏘️
        </div>

        <div class="logo-text">

            <h2>
                Karang Taruna
            </h2>

            <span>
                Sistem Informasi
            </span>

        </div>

    </div>


    <div class="menu-title">
        Menu Utama
    </div>


    <nav class="menu">

        <a href="../dashboard.php">

            <div class="menu-icon">
                🏠
            </div>

            <span>
                Dashboard
            </span>

        </a>


        <a href="../anggota/index.php">

            <div class="menu-icon">
                👥
            </div>

            <span>
                Data Anggota
            </span>

        </a>


        <a href="../alat/index.php">

            <div class="menu-icon">
                📦
            </div>

            <span>
                Data Alat
            </span>

        </a>


        <a
            href="index.php"
            class="active"
        >

            <div class="menu-icon">
                📋
            </div>

            <span>
                Peminjaman
            </span>

        </a>


        <a href="../pengembalian/index.php">

            <div class="menu-icon">
                🔄
            </div>

            <span>
                Pengembalian
            </span>

        </a>


        <a href="../laporan/peminjaman.php">

            <div class="menu-icon">
                📊
            </div>

            <span>
                Laporan
            </span>

        </a>

    </nav>


    <div class="logout">

        <a href="../logout.php">

            <div class="menu-icon">
                🚪
            </div>

            <span>
                Logout
            </span>

        </a>

    </div>

</aside>



<!-- =========================
     MAIN
========================= -->

<main class="main">


    <!-- TOPBAR -->

    <header class="topbar">

        <div class="page-title">

            <h2>
                Peminjaman Alat
            </h2>

            <p>
                Kelola transaksi peminjaman inventaris
            </p>

        </div>


        <div class="admin">

            <div class="admin-info">

                <strong>

                    <?php

                    echo htmlspecialchars(
                        $_SESSION['username']
                    );

                    ?>

                </strong>

                <span>
                    Admin
                </span>

            </div>


            <div class="admin-avatar">

                <?php

                echo strtoupper(
                    substr(
                        $_SESSION['username'],
                        0,
                        1
                    )
                );

                ?>

            </div>

        </div>

    </header>



    <!-- =========================
         CONTENT
    ========================= -->

    <section class="content">


        <div class="header-content">

            <div>

                <h1>
                    📋 Peminjaman Alat
                </h1>

                <p>
                    Kelola data peminjaman dan pengembalian alat
                </p>

            </div>


            <a
                href="tambah.php"
                class="btn-tambah"
            >

                + Peminjaman Baru

            </a>

        </div>



        <!-- =========================
             CARD
        ========================= -->

        <div class="card">


            <div class="card-header">

                <h3>
                    Riwayat Peminjaman
                </h3>

            </div>



            <div class="table-container">


                <table>


                    <thead>

                        <tr>

                            <th>
                                No
                            </th>

                            <th>
                                Peminjam
                            </th>

                            <th>
                                Alat
                            </th>

                            <th>
                                Jumlah
                            </th>

                            <th>
                                Tgl Pinjam
                            </th>

                            <th>
                                Tgl Kembali
                            </th>

                            <th>
                                Keperluan
                            </th>

                            <th>
                                Status
                            </th>

                            <th>
                                Aksi
                            </th>

                        </tr>

                    </thead>



                    <tbody>


                    <?php

                    $no = 1;


                    if (
                        mysqli_num_rows($query) > 0
                    ):


                        while (
                            $row =
                            mysqli_fetch_assoc($query)
                        ):


                            $status =
                                $row['status'];


                            /*
                             * Membuat class CSS
                             * berdasarkan status
                             */

                            $class =
                                strtolower(
                                    $status
                                );

                            $class =
                                str_replace(
                                    ' ',
                                    '-',
                                    $class
                                );

                    ?>


                    <tr>


                        <!-- NO -->

                        <td>

                            <?php
                            echo $no++;
                            ?>

                        </td>



                        <!-- PEMINJAM -->

                        <td>

                            <div
                                class="nama-peminjam"
                            >

                                <?php

                                echo htmlspecialchars(
                                    $row[
                                        'nama_peminjam'
                                    ] ?? '-'
                                );

                                ?>

                            </div>

                        </td>



                        <!-- ALAT -->

                        <td>

                            <?php

                            echo htmlspecialchars(
                                $row[
                                    'nama_alat'
                                ] ?? '-'
                            );

                            ?>

                        </td>



                        <!-- JUMLAH -->

                        <td>

                            <?php

                            echo htmlspecialchars(
                                $row[
                                    'jumlah_pinjam'
                                ] ?? '0'
                            );

                            ?>

                            unit

                        </td>



                        <!-- TANGGAL PINJAM -->

                        <td>

                            <?php

                            if (
                                !empty(
                                    $row[
                                        'tanggal_pinjam'
                                    ]
                                )
                            ) {

                                echo date(
                                    'd-m-Y',
                                    strtotime(
                                        $row[
                                            'tanggal_pinjam'
                                        ]
                                    )
                                );

                            } else {

                                echo '-';

                            }

                            ?>

                        </td>



                        <!-- TANGGAL KEMBALI -->

                        <td>

                            <?php

                            if (
                                !empty(
                                    $row[
                                        'tanggal_kembali'
                                    ]
                                )
                            ) {

                                echo date(
                                    'd-m-Y',
                                    strtotime(
                                        $row[
                                            'tanggal_kembali'
                                        ]
                                    )
                                );

                            } else {

                                echo '-';

                            }

                            ?>

                        </td>



                        <!-- KEPERLUAN -->

                        <td>

                            <?php

                            echo htmlspecialchars(
                                $row[
                                    'keperluan'
                                ] ?? '-'
                            );

                            ?>

                        </td>



                        <!-- STATUS -->

                        <td>

                            <span
                                class="badge <?php
                                    echo $class;
                                ?>"
                            >

                                <?php

                                echo htmlspecialchars(
                                    $status
                                );

                                ?>

                            </span>

                        </td>



                        <!-- =====================
                             AKSI
                        ====================== -->

                        <td>

                            <div class="action-box">


                                <?php

                                /*
                                 * STATUS MENUNGGU
                                 */

                                if (
                                    $status
                                    == 'Menunggu'
                                ):

                                ?>


                                    <!-- SETUJUI -->

                                    <a
                                        href="status.php?id=<?php
                                            echo $row[
                                                'id_peminjaman'
                                            ];
                                        ?>&status=Disetujui"

                                        class="btn btn-setujui"

                                        onclick="return confirm(
                                            'Yakin ingin menyetujui peminjaman ini?'
                                        )"
                                    >

                                        Setujui

                                    </a>


                                    <!-- TOLAK -->

                                    <a
                                        href="status.php?id=<?php
                                            echo $row[
                                                'id_peminjaman'
                                            ];
                                        ?>&status=Ditolak"

                                        class="btn btn-tolak"

                                        onclick="return confirm(
                                            'Yakin ingin menolak peminjaman ini?'
                                        )"
                                    >

                                        Tolak

                                    </a>


                                    <!-- EDIT MENUNGGU -->

                                    <a
                                        href="edit.php?id=<?php
                                            echo $row[
                                                'id_peminjaman'
                                            ];
                                        ?>"

                                        class="btn btn-edit"
                                    >

                                        Edit

                                    </a>


                                <?php


                                /*
                                 * STATUS DISETUJUI
                                 */

                                elseif (
                                    $status
                                    == 'Disetujui'
                                ):

                                ?>


                                    <!-- PENGEMBALIAN -->

                                    <a
                                        href="../pengembalian/index.php?id=<?php
                                            echo $row[
                                                'id_peminjaman'
                                            ];
                                        ?>"

                                        class="btn btn-selesai"
                                    >

                                        Pengembalian

                                    </a>


                                <?php


                                /*
                                 * STATUS DITOLAK
                                 */

                                elseif (
                                    $status
                                    == 'Ditolak'
                                ):

                                ?>


                                    <!-- EDIT DITOLAK -->

                                    <a
                                        href="edit.php?id=<?php
                                            echo $row[
                                                'id_peminjaman'
                                            ];
                                        ?>"

                                        class="btn btn-edit"
                                    >

                                        Edit

                                    </a>


                                <?php


                                /*
                                 * STATUS SELESAI
                                 *
                                 * TIDAK ADA TOMBOL EDIT
                                 *
                                 */

                                elseif (
                                    $status
                                    == 'Selesai'
                                ):

                                ?>

                                    <!--
                                        Untuk Selesai
                                        hanya Hapus
                                    -->

                                <?php endif; ?>


                                <!-- =====================
                                     HAPUS
                                     SELALU DITAMPILKAN
                                ====================== -->

                                <?php

                                /*
                                 * Hapus boleh dilakukan
                                 * untuk:
                                 *
                                 * Menunggu
                                 * Ditolak
                                 * Selesai
                                 *
                                 * Tetapi Disetujui
                                 * tidak boleh.
                                 */

                                if (
                                    $status
                                    != 'Disetujui'
                                ):

                                ?>

                                    <a
                                        href="hapus.php?id=<?php
                                            echo $row[
                                                'id_peminjaman'
                                            ];
                                        ?>"

                                        class="btn btn-hapus"

                                        onclick="return confirm(
                                            'Yakin ingin menghapus data peminjaman ini?'
                                        )"
                                    >

                                        Hapus

                                    </a>

                                <?php endif; ?>


                            </div>

                        </td>


                    </tr>


                    <?php

                        endwhile;


                    else:

                    ?>


                    <!-- DATA KOSONG -->

                    <tr>

                        <td
                            colspan="9"
                            class="empty"
                        >

                            <div
                                class="empty-icon"
                            >

                                📋

                            </div>


                            Belum ada data peminjaman.


                            <br>


                            <small>

                                Klik

                                <strong>
                                    + Peminjaman Baru
                                </strong>

                                untuk menambahkan data.

                            </small>

                        </td>

                    </tr>


                    <?php

                    endif;

                    ?>


                    </tbody>


                </table>


            </div>


        </div>


    </section>


</main>


</body>

</html>