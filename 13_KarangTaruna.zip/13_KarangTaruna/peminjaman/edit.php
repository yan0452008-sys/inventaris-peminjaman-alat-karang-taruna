<?php

session_start();

if (!isset($_SESSION['login'])) {
    header("Location: ../login.php");
    exit;
}

include "../koneksi.php";

$error = "";


/* =========================
   CEK ID PEMINJAMAN
========================= */

if (!isset($_GET['id']) || empty($_GET['id'])) {

    header("Location: index.php");
    exit;

}

$id = (int) $_GET['id'];


/* =========================
   AMBIL DATA PEMINJAMAN
========================= */

$query = mysqli_query($conn, "
    SELECT
        p.*,
        a.nama_alat,
        a.jumlah AS stok_alat
    FROM peminjaman p
    LEFT JOIN alat a
        ON p.id_alat = a.id_alat
    WHERE p.id_peminjaman = $id
");


if (!$query) {

    die(
        "Gagal mengambil data: " .
        mysqli_error($conn)
    );

}


if (mysqli_num_rows($query) == 0) {

    echo "<script>

        alert('Data peminjaman tidak ditemukan!');

        window.location='index.php';

    </script>";

    exit;

}


$data = mysqli_fetch_assoc($query);


/* =========================
   PROSES UPDATE
========================= */

if (isset($_POST['update'])) {


    $nama_peminjam = mysqli_real_escape_string(
        $conn,
        trim($_POST['nama_peminjam'])
    );


    $tanggal_pinjam = mysqli_real_escape_string(
        $conn,
        $_POST['tanggal_pinjam']
    );


    $tanggal_kembali = mysqli_real_escape_string(
        $conn,
        $_POST['tanggal_kembali']
    );


    $keperluan = mysqli_real_escape_string(
        $conn,
        trim($_POST['keperluan'])
    );


    $status_baru = mysqli_real_escape_string(
        $conn,
        $_POST['status']
    );


    /* =========================
       DATA LAMA
    ========================= */

    $status_lama = $data['status'];

    $id_alat = (int) $data['id_alat'];

    $jumlah_pinjam = (int) $data['jumlah_pinjam'];


    /* =========================
       VALIDASI TANGGAL
    ========================= */

    if ($tanggal_kembali < $tanggal_pinjam) {

        $error =
            "Tanggal kembali tidak boleh lebih awal " .
            "dari tanggal pinjam.";

    }


    /* =========================
       STATUS SELESAI
       TIDAK DIUBAH DARI EDIT
    ========================= */

    elseif (
        $status_baru == 'Selesai'
        &&
        $status_lama != 'Selesai'
    ) {

        $error =
            "Peminjaman tidak dapat diubah menjadi Selesai dari halaman Edit. " .
            "Silakan gunakan menu Pengembalian.";

    }


    /* =========================
       JIKA SUDAH SELESAI
    ========================= */

    elseif ($status_lama == 'Selesai') {

        $error =
            "Peminjaman yang sudah selesai tidak dapat diubah lagi.";

    }


    else {


        /* =========================
           MULAI TRANSAKSI
        ========================= */

        mysqli_begin_transaction($conn);


        try {


            /* =========================
               MENUNGGU → DISETUJUI
            ========================= */

            if (
                $status_lama == 'Menunggu'
                &&
                $status_baru == 'Disetujui'
            ) {


                /* =========================
                   CEK STOK TERBARU
                ========================= */

                $cek_alat = mysqli_query(
                    $conn,
                    "
                    SELECT jumlah, kondisi
                    FROM alat
                    WHERE id_alat = $id_alat
                    FOR UPDATE
                    "
                );


                if (!$cek_alat) {

                    throw new Exception(
                        mysqli_error($conn)
                    );

                }


                $alat = mysqli_fetch_assoc(
                    $cek_alat
                );


                if (!$alat) {

                    throw new Exception(
                        "Alat tidak ditemukan."
                    );

                }


                /* =========================
                   CEK KONDISI ALAT
                ========================= */

                if (
                    $alat['kondisi']
                    ==
                    'Rusak Berat'
                ) {

                    throw new Exception(
                        "Alat dalam kondisi Rusak Berat."
                    );

                }


                /* =========================
                   CEK STOK
                ========================= */

                if (
                    $jumlah_pinjam
                    >
                    (int) $alat['jumlah']
                ) {

                    throw new Exception(

                        "Stok alat tidak mencukupi. " .
                        "Stok tersedia: " .
                        $alat['jumlah'] .
                        " unit."

                    );

                }


                /* =========================
                   KURANGI STOK
                ========================= */

                $kurangi_stok = mysqli_query(
                    $conn,
                    "
                    UPDATE alat
                    SET jumlah =
                        jumlah - $jumlah_pinjam
                    WHERE id_alat = $id_alat
                    "
                );


                if (!$kurangi_stok) {

                    throw new Exception(
                        mysqli_error($conn)
                    );

                }

            }


            /* =========================
               DISETUJUI → MENUNGGU
               
               KEMBALIKAN STOK
               KARENA PEMINJAMAN
               DIBATALKAN
            ========================= */

            elseif (
                $status_lama == 'Disetujui'
                &&
                $status_baru == 'Menunggu'
            ) {


                $tambah_stok = mysqli_query(
                    $conn,
                    "
                    UPDATE alat
                    SET jumlah =
                        jumlah + $jumlah_pinjam
                    WHERE id_alat = $id_alat
                    "
                );


                if (!$tambah_stok) {

                    throw new Exception(
                        mysqli_error($conn)
                    );

                }

            }


            /* =========================
               DISETUJUI → DITOLAK
               
               KEMBALIKAN STOK
            ========================= */

            elseif (
                $status_lama == 'Disetujui'
                &&
                $status_baru == 'Ditolak'
            ) {


                $tambah_stok = mysqli_query(
                    $conn,
                    "
                    UPDATE alat
                    SET jumlah =
                        jumlah + $jumlah_pinjam
                    WHERE id_alat = $id_alat
                    "
                );


                if (!$tambah_stok) {

                    throw new Exception(
                        mysqli_error($conn)
                    );

                }

            }


            /* =========================
               UPDATE DATA PEMINJAMAN
            ========================= */

            $update = mysqli_query(
                $conn,
                "
                UPDATE peminjaman
                SET
                    nama_peminjam =
                        '$nama_peminjam',

                    tanggal_pinjam =
                        '$tanggal_pinjam',

                    tanggal_kembali =
                        '$tanggal_kembali',

                    keperluan =
                        '$keperluan',

                    status =
                        '$status_baru'

                WHERE id_peminjaman = $id
                "
            );


            if (!$update) {

                throw new Exception(
                    mysqli_error($conn)
                );

            }


            /* =========================
               SIMPAN TRANSAKSI
            ========================= */

            mysqli_commit($conn);


            echo "<script>

                alert(
                    'Data peminjaman berhasil diperbarui!'
                );

                window.location='index.php';

            </script>";

            exit;


        } catch (Exception $e) {


            /* =========================
               BATALKAN TRANSAKSI
            ========================= */

            mysqli_rollback($conn);


            $error =
                $e->getMessage();

        }

    }

}

?>

<!DOCTYPE html>

<html lang="id">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>
    Edit Peminjaman | Karang Taruna
</title>


<style>

* {

    box-sizing: border-box;

    margin: 0;

    padding: 0;

    font-family:
        "Segoe UI",
        Arial,
        sans-serif;

}


body {

    background:
        linear-gradient(
            135deg,
            #eef2ff,
            #f8fafc
        );

    min-height: 100vh;

    padding: 30px;

}


.container {

    max-width: 750px;

    margin: auto;

}


.header {

    background:
        linear-gradient(
            135deg,
            #2563eb,
            #4f46e5,
            #7c3aed
        );

    color: white;

    padding: 28px;

    border-radius:
        18px 18px 0 0;

}


.header h1 {

    font-size: 23px;

    margin-bottom: 5px;

}


.header p {

    font-size: 13px;

    color: #dbeafe;

}


.form-card {

    background: white;

    padding: 30px;

    border-radius:
        0 0 18px 18px;

    box-shadow:
        0 10px 30px
        rgba(15,23,42,.08);

}


.info {

    background: #eff6ff;

    border:
        1px solid #dbeafe;

    color: #1d4ed8;

    padding: 13px;

    border-radius: 10px;

    margin-bottom: 20px;

    font-size: 12px;

}


.error {

    background: #fee2e2;

    color: #991b1b;

    padding: 13px;

    border-radius: 10px;

    margin-bottom: 20px;

    font-size: 13px;

    border:
        1px solid #fecaca;

}


.form-group {

    margin-bottom: 20px;

}


label {

    display: block;

    margin-bottom: 7px;

    font-size: 13px;

    font-weight: 600;

    color: #334155;

}


input,
textarea,
select {

    width: 100%;

    padding: 12px 14px;

    border:
        1px solid #cbd5e1;

    border-radius: 10px;

    outline: none;

    font-size: 13px;

    transition: .2s;

}


input:focus,
textarea:focus,
select:focus {

    border-color:
        #2563eb;

    box-shadow:
        0 0 0 3px
        rgba(37,99,235,.10);

}


textarea {

    min-height: 110px;

    resize: vertical;

}


.stok-info {

    margin-top: 8px;

    padding: 10px;

    background: #f8fafc;

    border-radius: 8px;

    font-size: 12px;

    color: #64748b;

}


.status-info {

    padding: 12px;

    background: #fffbeb;

    border:
        1px solid #fde68a;

    border-radius: 9px;

    color: #92400e;

    font-size: 12px;

    margin-top: 8px;

}


.buttons {

    display: flex;

    gap: 10px;

    margin-top: 25px;

}


.btn {

    border: none;

    padding: 12px 20px;

    border-radius: 10px;

    text-decoration: none;

    cursor: pointer;

    font-size: 13px;

    font-weight: 600;

}


.btn-update {

    background:
        linear-gradient(
            135deg,
            #2563eb,
            #4f46e5
        );

    color: white;

}


.btn-back {

    background: #e2e8f0;

    color: #334155;

}


@media(max-width:600px) {

    body {

        padding: 15px;

    }


    .form-card {

        padding: 20px;

    }


    .buttons {

        flex-direction: column;

    }


    .btn {

        width: 100%;

        text-align: center;

    }

}

</style>

</head>


<body>


<div class="container">


    <div class="header">

        <h1>
            ✏️ Edit Peminjaman
        </h1>

        <p>
            Perbarui data peminjaman alat Karang Taruna
        </p>

    </div>


    <div class="form-card">


        <?php if ($error != ""): ?>

            <div class="error">

                ⚠️

                <?php
                echo htmlspecialchars($error);
                ?>

            </div>

        <?php endif; ?>


        <div class="info">

            📦 <strong>Alat:</strong>

            <?php
            echo htmlspecialchars(
                $data['nama_alat'] ?? '-'
            );
            ?>

            &nbsp; | &nbsp;

            <strong>Jumlah:</strong>

            <?php
            echo (int)
                $data['jumlah_pinjam'];
            ?>

            unit

        </div>


        <form
            method="POST"
            autocomplete="off"
        >


            <div class="form-group">

                <label>
                    Nama Peminjam
                </label>

                <input
                    type="text"
                    name="nama_peminjam"
                    value="<?php
                        echo htmlspecialchars(
                            $data[
                                'nama_peminjam'
                            ] ?? ''
                        );
                    ?>"
                    required
                >

            </div>


            <div class="form-group">

                <label>
                    Tanggal Pinjam
                </label>

                <input
                    type="date"
                    name="tanggal_pinjam"
                    value="<?php
                        echo htmlspecialchars(
                            $data[
                                'tanggal_pinjam'
                            ] ?? ''
                        );
                    ?>"
                    required
                >

            </div>


            <div class="form-group">

                <label>
                    Tanggal Kembali
                </label>

                <input
                    type="date"
                    name="tanggal_kembali"
                    value="<?php
                        echo htmlspecialchars(
                            $data[
                                'tanggal_kembali'
                            ] ?? ''
                        );
                    ?>"
                    required
                >

            </div>


            <div class="form-group">

                <label>
                    Keperluan
                </label>

                <textarea
                    name="keperluan"
                    required
                ><?php

                    echo htmlspecialchars(
                        $data[
                            'keperluan'
                        ] ?? ''
                    );

                ?></textarea>

            </div>


            <div class="form-group">

                <label>
                    Status Peminjaman
                </label>


                <?php if (
                    $data['status']
                    ==
                    'Disetujui'
                ): ?>

                    <select
                        name="status"
                        required
                    >

                        <option
                            value="Disetujui"
                            selected
                        >
                            Disetujui
                        </option>

                        <option
                            value="Ditolak"
                        >
                            Ditolak
                        </option>

                        <option
                            value="Menunggu"
                        >
                            Menunggu
                        </option>

                    </select>


                    <div class="status-info">

                        ⚠️ Peminjaman sudah disetujui
                        dan stok alat sudah dikurangi.

                        Jika alat sudah dikembalikan,
                        gunakan menu
                        <strong>
                            Pengembalian
                        </strong>.

                    </div>


                <?php elseif (
                    $data['status']
                    ==
                    'Selesai'
                ): ?>


                    <input
                        type="text"
                        value="Selesai"
                        disabled
                    >


                    <div class="status-info">

                        ✅ Peminjaman ini sudah selesai
                        dan alat telah dikembalikan.

                    </div>


                    <input
                        type="hidden"
                        name="status"
                        value="Selesai"
                    >


                <?php else: ?>


                    <select
                        name="status"
                        required
                    >

                        <option
                            value="Menunggu"
                            <?php

                            echo (
                                $data['status']
                                ==
                                'Menunggu'
                            )
                                ? 'selected'
                                : '';

                            ?>
                        >
                            Menunggu
                        </option>


                        <option
                            value="Disetujui"
                            <?php

                            echo (
                                $data['status']
                                ==
                                'Disetujui'
                            )
                                ? 'selected'
                                : '';

                            ?>
                        >
                            Disetujui
                        </option>


                        <option
                            value="Ditolak"
                            <?php

                            echo (
                                $data['status']
                                ==
                                'Ditolak'
                            )
                                ? 'selected'
                                : '';

                            ?>
                        >
                            Ditolak
                        </option>

                    </select>


                    <div class="status-info">

                        💡 Jika memilih
                        <strong>Disetujui</strong>,
                        stok alat otomatis dikurangi.

                    </div>


                <?php endif; ?>

            </div>


            <div class="buttons">


                <a
                    href="index.php"
                    class="btn btn-back"
                >
                    ← Kembali
                </a>


                <button
                    type="submit"
                    name="update"
                    class="btn btn-update"
                >

                    💾 Simpan Perubahan

                </button>


            </div>


        </form>


    </div>


</div>


</body>

</html>
