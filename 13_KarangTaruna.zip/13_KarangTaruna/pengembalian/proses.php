<?php

session_start();

if (!isset($_SESSION['login'])) {
    header("Location: ../login.php");
    exit;
}

include "../koneksi.php";


// =========================
// CEK ID PEMINJAMAN
// =========================

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$id_peminjaman = (int) $_GET['id'];


// =========================
// MULAI TRANSAKSI
// =========================

mysqli_begin_transaction($conn);

try {

    // =========================
    // AMBIL DATA PEMINJAMAN
    // =========================

    $query = mysqli_query(
        $conn,
        "
        SELECT
            id_peminjaman,
            id_alat,
            jumlah_pinjam,
            status
        FROM peminjaman
        WHERE id_peminjaman = $id_peminjaman
        FOR UPDATE
        "
    );

    if (!$query) {
        throw new Exception(
            "Gagal mengambil data peminjaman: "
            . mysqli_error($conn)
        );
    }


    // =========================
    // CEK DATA PEMINJAMAN
    // =========================

    if (mysqli_num_rows($query) == 0) {
        throw new Exception(
            "Data peminjaman tidak ditemukan."
        );
    }


    $data = mysqli_fetch_assoc($query);


    // =========================
    // CEK STATUS
    // =========================

    if ($data['status'] != 'Disetujui') {

        throw new Exception(
            "Peminjaman ini sudah diproses atau tidak sedang aktif."
        );
    }


    $id_alat = (int) $data['id_alat'];

    $jumlah_pinjam = (int) $data['jumlah_pinjam'];


    // =========================
    // CEK JUMLAH PINJAMAN
    // =========================

    if ($jumlah_pinjam <= 0) {

        throw new Exception(
            "Jumlah barang yang dikembalikan tidak valid."
        );
    }


    // =========================
    // KUNCI DATA ALAT
    // =========================

    $cek_alat = mysqli_query(
        $conn,
        "
        SELECT
            id_alat,
            nama_alat,
            jumlah
        FROM alat
        WHERE id_alat = $id_alat
        FOR UPDATE
        "
    );


    if (!$cek_alat) {

        throw new Exception(
            "Gagal mengambil data alat: "
            . mysqli_error($conn)
        );
    }


    // =========================
    // CEK ALAT
    // =========================

    if (mysqli_num_rows($cek_alat) == 0) {

        throw new Exception(
            "Data alat tidak ditemukan."
        );
    }


    $alat = mysqli_fetch_assoc($cek_alat);


    // =========================
    // TAMBAH STOK
    // =========================

    $update_alat = mysqli_query(
        $conn,
        "
        UPDATE alat
        SET jumlah = jumlah + $jumlah_pinjam
        WHERE id_alat = $id_alat
        "
    );


    if (!$update_alat) {

        throw new Exception(
            "Gagal mengembalikan stok alat: "
            . mysqli_error($conn)
        );
    }


    // =========================
    // UBAH STATUS
    // MENJADI SELESAI
    // =========================

    $update_peminjaman = mysqli_query(
        $conn,
        "
        UPDATE peminjaman
        SET status = 'Selesai'
        WHERE id_peminjaman = $id_peminjaman
        "
    );


    if (!$update_peminjaman) {

        throw new Exception(
            "Gagal mengubah status peminjaman: "
            . mysqli_error($conn)
        );
    }


    // =========================
    // SIMPAN TRANSAKSI
    // =========================

    mysqli_commit($conn);


    // =========================
    // BERHASIL
    // =========================

    echo "
    <script>
        alert('Pengembalian berhasil! Stok alat telah dikembalikan dan status menjadi Selesai.');
        window.location='index.php';
    </script>
    ";

    exit;


} catch (Exception $e) {


    // =========================
    // BATALKAN TRANSAKSI
    // =========================

    mysqli_rollback($conn);


    $pesan = json_encode(
        "Pengembalian gagal: "
        . $e->getMessage()
    );


    echo "
    <script>
        alert($pesan);
        window.location='index.php';
    </script>
    ";

    exit;
}

?>