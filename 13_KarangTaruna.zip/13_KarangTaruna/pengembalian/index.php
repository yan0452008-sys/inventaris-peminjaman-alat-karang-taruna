<?php

session_start();

if (!isset($_SESSION['login'])) {
    header("Location: ../login.php");
    exit;
}

include "../koneksi.php";


/* =========================
   DATA PEMINJAMAN AKTIF
========================= */

$query = mysqli_query($conn, "
    SELECT
        p.*,
        al.nama_alat
    FROM peminjaman p
    LEFT JOIN alat al
        ON p.id_alat = al.id_alat
    WHERE p.status = 'Disetujui'
    ORDER BY p.id_peminjaman DESC
");


if (!$query) {

    die(
        "Gagal mengambil data: "
        . mysqli_error($conn)
    );

}

?>

<!DOCTYPE html>

<html lang="id">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>
    Pengembalian | Karang Taruna
</title>


<style>

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: "Segoe UI", Arial, sans-serif;
}

body {
    background: #f1f5f9;
    color: #1e293b;
}


/* =========================
   SIDEBAR
========================= */

.sidebar {

    position: fixed;

    left: 0;
    top: 0;

    width: 250px;
    height: 100vh;

    background:
        linear-gradient(
            180deg,
            #1e3a8a,
            #312e81
        );

    color: white;

    padding: 25px 18px;

    z-index: 1000;
}


.logo {

    display: flex;

    align-items: center;

    gap: 12px;

    padding: 10px;

    margin-bottom: 35px;
}


.logo-icon {

    width: 45px;
    height: 45px;

    border-radius: 12px;

    background:
        rgba(255,255,255,.15);

    display: flex;

    align-items: center;
    justify-content: center;

    font-size: 23px;
}


.logo-text h2 {
    font-size: 17px;
}


.logo-text span {

    font-size: 11px;

    color: #c7d2fe;
}


/* MENU */

.menu-title {

    font-size: 11px;

    color: #a5b4fc;

    margin:
        20px 12px 10px;

    text-transform: uppercase;

    letter-spacing: 1px;
}


.menu a {

    display: flex;

    align-items: center;

    gap: 13px;

    color: #e0e7ff;

    text-decoration: none;

    padding: 12px 14px;

    margin: 5px 0;

    border-radius: 10px;

    font-size: 14px;

    transition: .3s;
}


.menu a:hover,
.menu a.active {

    background:
        rgba(255,255,255,.14);

    color: white;
}


.menu-icon {

    width: 25px;

    text-align: center;

    font-size: 17px;
}


/* LOGOUT */

.logout {

    position: absolute;

    bottom: 25px;

    left: 18px;
    right: 18px;
}


.logout a {

    display: flex;

    align-items: center;

    gap: 13px;

    color: #fecaca;

    text-decoration: none;

    padding: 12px 14px;

    border-radius: 10px;

    background:
        rgba(239,68,68,.15);
}


/* =========================
   MAIN
========================= */

.main {

    margin-left: 250px;

    min-height: 100vh;
}


/* TOPBAR */

.topbar {

    height: 75px;

    background: white;

    display: flex;

    align-items: center;

    justify-content: space-between;

    padding: 0 35px;

    border-bottom:
        1px solid #e2e8f0;
}


.page-title h2 {

    font-size: 20px;

    color: #0f172a;
}


.page-title p {

    font-size: 12px;

    color: #94a3b8;

    margin-top: 3px;
}


.admin {

    display: flex;

    align-items: center;

    gap: 12px;
}


.admin-info {

    text-align: right;
}


.admin-info strong {

    display: block;

    font-size: 13px;
}


.admin-info span {

    font-size: 11px;

    color: #94a3b8;
}


.admin-avatar {

    width: 40px;
    height: 40px;

    border-radius: 50%;

    background:
        linear-gradient(
            135deg,
            #2563eb,
            #7c3aed
        );

    color: white;

    display: flex;

    align-items: center;
    justify-content: center;

    font-weight: bold;
}


/* =========================
   CONTENT
========================= */

.content {

    padding: 30px 35px;
}


.header-content {

    display: flex;

    justify-content: space-between;

    align-items: center;

    margin-bottom: 25px;
}


.header-content h1 {

    font-size: 25px;

    color: #0f172a;
}


.header-content p {

    color: #64748b;

    font-size: 13px;

    margin-top: 5px;
}


/* =========================
   CARD
========================= */

.card {

    background: white;

    border:
        1px solid #e2e8f0;

    border-radius: 15px;

    overflow: hidden;

    box-shadow:
        0 5px 20px
        rgba(15,23,42,.03);
}


.card-header {

    padding: 20px;

    border-bottom:
        1px solid #e2e8f0;
}


.card-header h3 {

    font-size: 16px;
}


/* =========================
   TABLE
========================= */

.table-container {

    overflow-x: auto;
}


table {

    width: 100%;

    border-collapse:
        collapse;
}


th {

    text-align: left;

    padding: 14px 20px;

    background: #f8fafc;

    color: #64748b;

    font-size: 11px;

    text-transform: uppercase;

    white-space: nowrap;
}


td {

    padding: 15px 20px;

    border-top:
        1px solid #f1f5f9;

    font-size: 13px;

    vertical-align: middle;
}


tr:hover {

    background: #f8fafc;
}


/* PEMINJAM */

.nama-peminjam {

    font-weight: 600;

    color: #0f172a;
}


/* BADGE */

.badge {

    display: inline-block;

    padding: 6px 11px;

    border-radius: 20px;

    font-size: 10px;

    font-weight: 600;
}


.disetujui {

    background: #dbeafe;

    color: #1d4ed8;
}


/* BUTTON */

.btn-kembali {

    display: inline-block;

    padding: 8px 13px;

    border-radius: 8px;

    background:
        #dcfce7;

    color:
        #166534;

    text-decoration: none;

    font-size: 11px;

    font-weight: 600;

    transition: .2s;
}


.btn-kembali:hover {

    background:
        #bbf7d0;

    transform:
        translateY(-1px);
}


/* EMPTY */

.empty {

    text-align: center;

    padding: 60px;

    color: #94a3b8;
}


.empty-icon {

    font-size: 45px;

    margin-bottom: 12px;
}


/* RESPONSIVE */

@media(max-width:800px) {

    .sidebar {

        width: 70px;

        padding:
            20px 10px;
    }


    .logo-text,
    .menu-title,
    .menu a span {

        display: none;
    }


    .logo {

        justify-content:
            center;
    }


    .menu a {

        justify-content:
            center;
    }


    .logout {

        left: 10px;
        right: 10px;
    }


    .logout a {

        justify-content:
            center;
    }


    .main {

        margin-left: 70px;
    }


    .content {

        padding:
            20px 15px;
    }


    .topbar {

        padding:
            0 15px;
    }


    .admin-info {

        display: none;
    }

}

</style>

</head>


<body>


<!-- SIDEBAR -->

<aside class="sidebar">


    <div class="logo">

        <div class="logo-icon">
            🏘️
        </div>


        <div class="logo-text">

            <h2>
                Karang Taruna
            </h2>

            <span>
                Sistem Informasi
            </span>

        </div>

    </div>


    <div class="menu-title">
        Menu Utama
    </div>


    <nav class="menu">


        <a href="../dashboard.php">

            <div class="menu-icon">
                🏠
            </div>

            <span>
                Dashboard
            </span>

        </a>


        <a href="../anggota/index.php">

            <div class="menu-icon">
                👥
            </div>

            <span>
                Data Anggota
            </span>

        </a>


        <a href="../alat/index.php">

            <div class="menu-icon">
                📦
            </div>

            <span>
                Data Alat
            </span>

        </a>


        <a href="../peminjaman/index.php">

            <div class="menu-icon">
                📋
            </div>

            <span>
                Peminjaman
            </span>

        </a>


        <a
            href="index.php"
            class="active"
        >

            <div class="menu-icon">
                🔄
            </div>

            <span>
                Pengembalian
            </span>

        </a>


        <a href="../laporan/peminjaman.php">

            <div class="menu-icon">
                📊
            </div>

            <span>
                Laporan
            </span>

        </a>


    </nav>


    <div class="logout">

        <a href="../logout.php">

            <div class="menu-icon">
                🚪
            </div>

            <span>
                Logout
            </span>

        </a>

    </div>


</aside>



<!-- MAIN -->

<main class="main">


    <!-- TOPBAR -->

    <header class="topbar">


        <div class="page-title">

            <h2>
                Pengembalian Alat
            </h2>

            <p>
                Kelola pengembalian inventaris Karang Taruna
            </p>

        </div>


        <div class="admin">


            <div class="admin-info">

                <strong>

                    <?php

                    echo htmlspecialchars(
                        $_SESSION['username']
                    );

                    ?>

                </strong>

                <span>
                    Admin
                </span>

            </div>


            <div class="admin-avatar">

                <?php

                echo strtoupper(
                    substr(
                        $_SESSION['username'],
                        0,
                        1
                    )
                );

                ?>

            </div>

        </div>

    </header>



    <!-- CONTENT -->

    <section class="content">


        <div class="header-content">


            <div>

                <h1>
                    🔄 Pengembalian Alat
                </h1>

                <p>
                    Daftar peminjaman yang sedang berlangsung
                </p>

            </div>


        </div>



        <!-- CARD -->

        <div class="card">


            <div class="card-header">

                <h3>
                    Peminjaman Aktif
                </h3>

            </div>


            <div class="table-container">


                <table>


                    <thead>

                        <tr>

                            <th>
                                No
                            </th>

                            <th>
                                Peminjam
                            </th>

                            <th>
                                Alat
                            </th>

                            <th>
                                Jumlah
                            </th>

                            <th>
                                Tanggal Pinjam
                            </th>

                            <th>
                                Rencana Kembali
                            </th>

                            <th>
                                Keperluan
                            </th>

                            <th>
                                Status
                            </th>

                            <th>
                                Aksi
                            </th>

                        </tr>

                    </thead>


                    <tbody>


                    <?php

                    $no = 1;


                    if (
                        mysqli_num_rows($query) > 0
                    ):

                        while (
                            $row =
                            mysqli_fetch_assoc($query)
                        ):

                    ?>


                    <tr>


                        <td>
                            <?php
                            echo $no++;
                            ?>
                        </td>


                        <td>

                            <div class="nama-peminjam">

                                <?php

                                echo htmlspecialchars(
                                    $row[
                                        'nama_peminjam'
                                    ] ?? '-'
                                );

                                ?>

                            </div>

                        </td>


                        <td>

                            <?php

                            echo htmlspecialchars(
                                $row[
                                    'nama_alat'
                                ] ?? '-'
                            );

                            ?>

                        </td>


                        <td>

                            <?php

                            echo htmlspecialchars(
                                $row[
                                    'jumlah_pinjam'
                                ] ?? '0'
                            );

                            ?>

                            unit

                        </td>


                        <td>

                            <?php

                            if (
                                !empty(
                                    $row[
                                        'tanggal_pinjam'
                                    ]
                                )
                            ) {

                                echo date(
                                    'd-m-Y',
                                    strtotime(
                                        $row[
                                            'tanggal_pinjam'
                                        ]
                                    )
                                );

                            } else {

                                echo '-';

                            }

                            ?>

                        </td>


                        <td>

                            <?php

                            if (
                                !empty(
                                    $row[
                                        'tanggal_kembali'
                                    ]
                                )
                            ) {

                                echo date(
                                    'd-m-Y',
                                    strtotime(
                                        $row[
                                            'tanggal_kembali'
                                        ]
                                    )
                                );

                            } else {

                                echo '-';

                            }

                            ?>

                        </td>


                        <td>

                            <?php

                            echo htmlspecialchars(
                                $row[
                                    'keperluan'
                                ] ?? '-'
                            );

                            ?>

                        </td>


                        <td>

                            <span
                                class="badge disetujui"
                            >

                                Disetujui

                            </span>

                        </td>


                        <td>

                           <a
                           href="proses.php?id=<?php echo $row['id_peminjaman']; ?>"
                           class="btn-kembali"
                           onclick="return confirm('Yakin alat ini sudah dikembalikan? Stok alat akan otomatis bertambah.');"
                           >
                           ✅ Kembalikan
                           </a>


                        </td>


                    </tr>


                    <?php

                        endwhile;

                    else:

                    ?>


                    <tr>

                        <td
                            colspan="9"
                            class="empty"
                        >

                            <div
                                class="empty-icon"
                            >
                                📦
                            </div>


                            Tidak ada alat yang sedang dipinjam.


                            <br>


                            <small>
                                Semua alat sudah dikembalikan.
                            </small>

                        </td>

                    </tr>


                    <?php

                    endif;

                    ?>


                    </tbody>

                </table>

            </div>

        </div>


    </section>


</main>


</body>

</html>
