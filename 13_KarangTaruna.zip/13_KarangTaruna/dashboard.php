<?php

session_start();

if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

include "koneksi.php";

/* =========================
   DATA DASHBOARD
========================= */

// Jumlah anggota
$query_anggota = mysqli_query(
    $conn,
    "SELECT COUNT(*) AS total FROM anggota"
);

$data_anggota = mysqli_fetch_assoc($query_anggota);
$total_anggota = $data_anggota['total'];


// Jumlah jenis alat
$query_alat = mysqli_query(
    $conn,
    "SELECT COUNT(*) AS total FROM alat"
);

$data_alat = mysqli_fetch_assoc($query_alat);
$total_alat = $data_alat['total'];


// Total unit alat
$query_total_alat = mysqli_query(
    $conn,
    "SELECT COALESCE(SUM(jumlah),0) AS total FROM alat"
);

$data_total_alat = mysqli_fetch_assoc($query_total_alat);
$total_unit_alat = $data_total_alat['total'];


// Peminjaman menunggu
$query_menunggu = mysqli_query(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM peminjaman
    WHERE status = 'Menunggu'
    "
);

$data_menunggu = mysqli_fetch_assoc($query_menunggu);
$total_menunggu = $data_menunggu['total'];


// Peminjaman aktif
$query_aktif = mysqli_query(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM peminjaman
    WHERE status = 'Disetujui'
    "
);

$data_aktif = mysqli_fetch_assoc($query_aktif);
$total_aktif = $data_aktif['total'];


// Peminjaman selesai
$query_selesai = mysqli_query(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM peminjaman
    WHERE status = 'Selesai'
    "
);

$data_selesai = mysqli_fetch_assoc($query_selesai);
$total_selesai = $data_selesai['total'];


// Peminjaman terbaru
$query_terbaru = mysqli_query(
    $conn,
    "
    SELECT
        p.*,
        al.nama_alat
    FROM peminjaman p
    LEFT JOIN alat al
        ON p.id_alat = al.id_alat
    ORDER BY p.id_peminjaman DESC
    LIMIT 5
    "
);

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Dashboard | Karang Taruna</title>


    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Segoe UI", Arial, sans-serif;
        }


        body {
            background: #f1f5f9;
            color: #1e293b;
        }


        /* =========================
           SIDEBAR
        ========================= */

        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 250px;
            height: 100vh;

            background:
                linear-gradient(
                    180deg,
                    #1e3a8a,
                    #312e81
                );

            color: white;
            padding: 25px 18px;
            z-index: 1000;
        }


        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px;
            margin-bottom: 35px;
        }


        .logo-icon {
            width: 45px;
            height: 45px;

            border-radius: 12px;

            display: flex;
            align-items: center;
            justify-content: center;

            background: rgba(255,255,255,0.15);

            font-size: 23px;
        }


        .logo-text h2 {
            font-size: 17px;
        }


        .logo-text span {
            font-size: 11px;
            color: #c7d2fe;
        }


        /* =========================
           MENU
        ========================= */

        .menu-title {
            font-size: 11px;
            color: #a5b4fc;

            margin:
                20px 12px 10px;

            text-transform: uppercase;
            letter-spacing: 1px;
        }


        .menu a {
            display: flex;
            align-items: center;
            gap: 13px;

            color: #e0e7ff;

            text-decoration: none;

            padding: 12px 14px;
            margin: 5px 0;

            border-radius: 10px;

            transition: 0.3s;

            font-size: 14px;
        }


        .menu a:hover,
        .menu a.active {
            background: rgba(255,255,255,0.14);
            color: white;
        }


        .menu-icon {
            width: 25px;
            text-align: center;
            font-size: 17px;
        }


        /* =========================
           LOGOUT
        ========================= */

        .logout {
            position: absolute;
            bottom: 25px;
            left: 18px;
            right: 18px;
        }


        .logout a {
            display: flex;
            align-items: center;
            gap: 13px;

            color: #fecaca !important;

            text-decoration: none;

            padding: 12px 14px;

            border-radius: 10px;

            background: rgba(239,68,68,0.15);
        }


        /* =========================
           MAIN
        ========================= */

        .main {
            margin-left: 250px;
            min-height: 100vh;
        }


        /* =========================
           TOPBAR
        ========================= */

        .topbar {
            height: 75px;

            background: white;

            display: flex;
            align-items: center;
            justify-content: space-between;

            padding: 0 35px;

            border-bottom:
                1px solid #e2e8f0;
        }


        .page-title h2 {
            font-size: 20px;
            color: #0f172a;
        }


        .page-title p {
            font-size: 12px;
            color: #94a3b8;
            margin-top: 3px;
        }


        .admin {
            display: flex;
            align-items: center;
            gap: 12px;
        }


        .admin-info {
            text-align: right;
        }


        .admin-info strong {
            display: block;
            font-size: 13px;
        }


        .admin-info span {
            font-size: 11px;
            color: #94a3b8;
        }


        .admin-avatar {
            width: 40px;
            height: 40px;

            border-radius: 50%;

            display: flex;
            align-items: center;
            justify-content: center;

            color: white;

            background:
                linear-gradient(
                    135deg,
                    #2563eb,
                    #7c3aed
                );

            font-weight: bold;
        }


        /* =========================
           CONTENT
        ========================= */

        .content {
            padding: 30px 35px;
        }


        /* =========================
           WELCOME
        ========================= */

        .welcome {
            background:
                linear-gradient(
                    135deg,
                    #2563eb,
                    #4f46e5,
                    #7c3aed
                );

            color: white;

            padding: 28px 30px;

            border-radius: 18px;

            margin-bottom: 25px;

            position: relative;
            overflow: hidden;
        }


        .welcome::after {
            content: "";

            position: absolute;

            width: 220px;
            height: 220px;

            border-radius: 50%;

            background:
                rgba(255,255,255,0.08);

            right: -70px;
            top: -90px;
        }


        .welcome h1 {
            font-size: 25px;
            margin-bottom: 7px;
        }


        .welcome p {
            color: #dbeafe;
            font-size: 13px;
        }


        /* =========================
           STATISTICS
        ========================= */

        .stats {
            display: grid;

            grid-template-columns:
                repeat(4, 1fr);

            gap: 18px;

            margin-bottom: 25px;
        }


        .stat-card {
            background: white;

            border-radius: 15px;

            padding: 20px;

            border:
                1px solid #e2e8f0;

            transition: 0.3s;
        }


        .stat-card:hover {
            transform: translateY(-4px);

            box-shadow:
                0 12px 30px
                rgba(15,23,42,0.08);
        }


        .stat-top {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }


        .stat-card p {
            font-size: 12px;
            color: #64748b;
        }


        .stat-card h3 {
            font-size: 27px;

            margin-top: 8px;

            color: #0f172a;
        }


        .stat-icon {
            width: 45px;
            height: 45px;

            border-radius: 12px;

            display: flex;
            align-items: center;
            justify-content: center;

            font-size: 21px;
        }


        .blue {
            background: #dbeafe;
        }


        .purple {
            background: #ede9fe;
        }


        .orange {
            background: #ffedd5;
        }


        .green {
            background: #dcfce7;
        }


        /* =========================
           GRID
        ========================= */

        .dashboard-grid {
            display: grid;

            grid-template-columns:
                2fr 1fr;

            gap: 20px;
        }


        /* =========================
           PANEL
        ========================= */

        .panel {
            background: white;

            border-radius: 15px;

            border:
                1px solid #e2e8f0;

            overflow: hidden;
        }


        .panel-header {
            display: flex;
            align-items: center;
            justify-content: space-between;

            padding: 20px;

            border-bottom:
                1px solid #e2e8f0;
        }


        .panel-header h3 {
            font-size: 16px;
        }


        .panel-header a {
            color: #2563eb;
            text-decoration: none;
            font-size: 12px;
        }


        /* =========================
           TABLE
        ========================= */

        .table-container {
            overflow-x: auto;
        }


        table {
            width: 100%;
            border-collapse: collapse;
        }


        th {
            text-align: left;

            font-size: 11px;

            color: #94a3b8;

            padding: 14px 20px;

            background: #f8fafc;
        }


        td {
            padding: 15px 20px;

            border-top:
                1px solid #f1f5f9;

            font-size: 12px;
        }


        tr:hover {
            background: #f8fafc;
        }


        /* =========================
           BADGE
        ========================= */

        .badge {
            display: inline-block;

            padding: 5px 9px;

            border-radius: 20px;

            font-size: 10px;

            font-weight: 600;
        }


        .badge-menunggu {
            background: #fef3c7;
            color: #92400e;
        }


        .badge-disetujui {
            background: #dbeafe;
            color: #1d4ed8;
        }


        .badge-selesai {
            background: #dcfce7;
            color: #166534;
        }


        .badge-ditolak {
            background: #fee2e2;
            color: #991b1b;
        }


        /* =========================
           QUICK MENU
        ========================= */

        .quick-menu {
            padding: 20px;

            display: grid;

            grid-template-columns:
                1fr 1fr;

            gap: 12px;
        }


        .quick {
            text-decoration: none;

            padding: 18px 12px;

            border-radius: 12px;

            background: #f8fafc;

            color: #334155;

            text-align: center;

            transition: 0.3s;

            border:
                1px solid #f1f5f9;
        }


        .quick:hover {
            background: #eff6ff;

            border-color: #bfdbfe;

            transform:
                translateY(-2px);
        }


        .quick-icon {
            font-size: 25px;
            margin-bottom: 7px;
        }


        .quick span {
            display: block;
            font-size: 11px;
        }


        /* =========================
           INFORMASI KARANG TARUNA
        ========================= */

        .info-section {
            margin-top: 25px;
        }


        .info-section-title {
            margin-bottom: 15px;
        }


        .info-section-title h3 {
            font-size: 18px;
            color: #0f172a;
            margin-bottom: 4px;
        }


        .info-section-title p {
            font-size: 12px;
            color: #64748b;
        }


        .info-cards {
            display: grid;

            grid-template-columns:
                repeat(2, 1fr);

            gap: 18px;
        }


        .info-card {
            background: white;

            border:
                1px solid #e2e8f0;

            border-radius: 15px;

            padding: 22px;

            transition: 0.3s;
        }


        .info-card:hover {
            transform: translateY(-3px);

            box-shadow:
                0 10px 25px
                rgba(15,23,42,0.08);

            border-color: #bfdbfe;
        }


        .info-card-header {
            display: flex;

            align-items: center;

            gap: 12px;

            margin-bottom: 14px;
        }


        .info-card-icon {
            width: 42px;
            height: 42px;

            border-radius: 11px;

            display: flex;
            align-items: center;
            justify-content: center;

            background: #dbeafe;

            color: #1d4ed8;

            font-size: 19px;

            flex-shrink: 0;
        }


        .info-card h4 {
            font-size: 15px;
            color: #0f172a;
        }


        .info-card p {
            font-size: 12px;

            line-height: 1.8;

            color: #64748b;
        }


        .info-card ol {
            padding-left: 19px;

            color: #64748b;
        }


        .info-card li {
            font-size: 12px;

            line-height: 1.8;

            margin-bottom: 3px;
        }


        .info-card.visi {
            border-top:
                4px solid #2563eb;
        }


        .info-card.misi {
            border-top:
                4px solid #4f46e5;
        }


        .info-card.ketentuan {
            border-top:
                4px solid #0ea5e9;
        }


        .info-card.kegiatan {
            border-top:
                4px solid #7c3aed;
        }


        /* =========================
           INFO BAWAH
        ========================= */

        .info-box {
            margin-top: 20px;

            padding: 16px 20px;

            background: white;

            border:
                1px solid #e2e8f0;

            border-radius: 15px;

            color: #64748b;

            font-size: 12px;
        }


        /* =========================
           RESPONSIVE
        ========================= */

        @media (max-width: 1100px) {

            .stats {
                grid-template-columns:
                    repeat(2, 1fr);
            }


            .dashboard-grid {
                grid-template-columns:
                    1fr;
            }

        }


        @media (max-width: 700px) {

            .sidebar {
                width: 70px;

                padding:
                    20px 10px;
            }


            .logo-text,
            .menu-title,
            .menu a span {
                display: none;
            }


            .logo {
                justify-content:
                    center;
            }


            .menu a {
                justify-content:
                    center;
            }


            .logout {
                left: 10px;
                right: 10px;
            }


            .logout a {
                justify-content:
                    center;
            }


            .main {
                margin-left: 70px;
            }


            .topbar {
                padding:
                    0 15px;
            }


            .content {
                padding:
                    20px 15px;
            }


            .stats {
                grid-template-columns:
                    1fr;
            }


            .admin-info {
                display: none;
            }


            .info-cards {
                grid-template-columns:
                    1fr;
            }

        }

    </style>

</head>


<body>


<!-- =========================
     SIDEBAR
========================= -->

<aside class="sidebar">


    <div class="logo">

        <div class="logo-icon">
            🏘️
        </div>


        <div class="logo-text">

            <h2>
                Karang Taruna Manunggal Bhakti
            </h2>

            <span>
                Sistem Informasi
            </span>

        </div>

    </div>


    <div class="menu-title">
        Menu Utama
    </div>


    <nav class="menu">


        <!-- DASHBOARD -->

        <a
            href="dashboard.php"
            class="active"
        >

            <div class="menu-icon">
                🏠
            </div>

            <span>
                Dashboard
            </span>

        </a>


        <!-- ANGGOTA -->

        <a href="anggota/index.php">

            <div class="menu-icon">
                👥
            </div>

            <span>
                Data Anggota
            </span>

        </a>


        <!-- ALAT -->

        <a href="alat/index.php">

            <div class="menu-icon">
                📦
            </div>

            <span>
                Data Alat
            </span>

        </a>


        <!-- PEMINJAMAN -->

        <a href="peminjaman/index.php">

            <div class="menu-icon">
                📋
            </div>

            <span>
                Peminjaman
            </span>

        </a>


        <!-- PENGEMBALIAN -->

        <a href="pengembalian/index.php">

            <div class="menu-icon">
                🔄
            </div>

            <span>
                Pengembalian
            </span>

        </a>


        <!-- LAPORAN -->

        <div class="menu-title">
            Laporan
        </div>


        <a href="laporan/peminjaman.php">

            <div class="menu-icon">
                📊
            </div>

            <span>
                Laporan
            </span>

        </a>


    </nav>


    <!-- LOGOUT -->

    <div class="logout">

        <a href="logout.php">

            <div class="menu-icon">
                🚪
            </div>

            <span>
                Logout
            </span>

        </a>

    </div>


</aside>



<!-- =========================
     MAIN
========================= -->

<main class="main">


    <!-- TOPBAR -->

    <header class="topbar">


        <div class="page-title">

            <h2>
                Dashboard
            </h2>

            <p>
                Sistem Informasi Karang Taruna Manunggal Bhakti
            </p>

        </div>


        <div class="admin">


            <div class="admin-info">

                <strong>

                    <?php

                    echo htmlspecialchars(
                        $_SESSION['username']
                    );

                    ?>

                </strong>


                <span>
                    Pengurus
                </span>

            </div>


            <div class="admin-avatar">

                <?php

                echo strtoupper(
                    substr(
                        $_SESSION['username'],
                        0,
                        1
                    )
                );

                ?>

            </div>


        </div>


    </header>



    <!-- =========================
         CONTENT
    ========================= -->

    <section class="content">


        <!-- WELCOME -->

        <div class="welcome">

            <h1>
                Selamat datang kembali, Admin!
            </h1>

            <p>
                Kelola anggota, inventaris, peminjaman
                dan pengembalian alat Karang Taruna
                dari satu tempat.
            </p>

        </div>



        <!-- =========================
             STATISTIK
        ========================= -->

        <div class="stats">


            <!-- ANGGOTA -->

            <div class="stat-card">

                <div class="stat-top">

                    <div>

                        <p>
                            Total Anggota
                        </p>

                        <h3>
                            <?php
                            echo $total_anggota;
                            ?>
                        </h3>

                    </div>


                    <div class="stat-icon blue">
                        👥
                    </div>

                </div>

            </div>



            <!-- ALAT -->

            <div class="stat-card">

                <div class="stat-top">

                    <div>

                        <p>
                            Jenis Alat
                        </p>

                        <h3>
                            <?php
                            echo $total_alat;
                            ?>
                        </h3>

                    </div>


                    <div class="stat-icon purple">
                        📦
                    </div>

                </div>

            </div>



            <!-- MENUNGGU -->

            <div class="stat-card">

                <div class="stat-top">

                    <div>

                        <p>
                            Menunggu
                        </p>

                        <h3>
                            <?php
                            echo $total_menunggu;
                            ?>
                        </h3>

                    </div>


                    <div class="stat-icon orange">
                        ⏳
                    </div>

                </div>

            </div>



            <!-- AKTIF -->

            <div class="stat-card">

                <div class="stat-top">

                    <div>

                        <p>
                            Peminjaman Aktif
                        </p>

                        <h3>
                            <?php
                            echo $total_aktif;
                            ?>
                        </h3>

                    </div>


                    <div class="stat-icon green">
                        🔄
                    </div>

                </div>

            </div>


        </div>



        <!-- =========================
             GRID
        ========================= -->

        <div class="dashboard-grid">


            <!-- PEMINJAMAN TERBARU -->

            <div class="panel">


                <div class="panel-header">

                    <h3>
                        📋 Peminjaman Terbaru
                    </h3>


                    <a href="peminjaman/index.php">
                        Lihat semua →
                    </a>

                </div>



                <div class="table-container">


                    <table>


                        <thead>

                            <tr>

                                <th>
                                    PEMINJAM
                                </th>

                                <th>
                                    ALAT
                                </th>

                                <th>
                                    TANGGAL
                                </th>

                                <th>
                                    STATUS
                                </th>

                            </tr>

                        </thead>


                        <tbody>


                        <?php

                        if (
                            mysqli_num_rows(
                                $query_terbaru
                            ) > 0
                        ):

                        ?>


                        <?php

                        while (
                            $row =
                            mysqli_fetch_assoc(
                                $query_terbaru
                            )
                        ):

                            $status =
                                $row['status'];

                            $class = '';

                            if (
                                $status ==
                                'Menunggu'
                            ) {

                                $class =
                                    'badge-menunggu';

                            } elseif (
                                $status ==
                                'Disetujui'
                            ) {

                                $class =
                                    'badge-disetujui';

                            } elseif (
                                $status ==
                                'Selesai'
                            ) {

                                $class =
                                    'badge-selesai';

                            } elseif (
                                $status ==
                                'Ditolak'
                            ) {

                                $class =
                                    'badge-ditolak';

                            }

                        ?>


                        <tr>


                            <!-- PEMINJAM -->

                            <td>

                                <strong>

                                    <?php

                                    echo htmlspecialchars(
                                        $row[
                                            'nama_peminjam'
                                        ] ?? '-'
                                    );

                                    ?>

                                </strong>

                            </td>


                            <!-- ALAT -->

                            <td>

                                <?php

                                echo htmlspecialchars(
                                    $row[
                                        'nama_alat'
                                    ] ?? '-'
                                );

                                ?>

                            </td>


                            <!-- TANGGAL -->

                            <td>

                                <?php

                                if (
                                    !empty(
                                        $row[
                                            'tanggal_pinjam'
                                        ]
                                    )
                                ) {

                                    echo date(
                                        'd/m/Y',
                                        strtotime(
                                            $row[
                                                'tanggal_pinjam'
                                            ]
                                        )
                                    );

                                } else {

                                    echo '-';

                                }

                                ?>

                            </td>


                            <!-- STATUS -->

                            <td>

                                <span
                                    class="badge <?php echo $class; ?>"
                                >

                                    <?php

                                    echo htmlspecialchars(
                                        $status
                                    );

                                    ?>

                                </span>

                            </td>


                        </tr>


                        <?php

                        endwhile;

                        ?>


                        <?php

                        else:

                        ?>


                        <tr>

                            <td
                                colspan="4"
                                style="
                                    text-align:center;
                                    color:#94a3b8;
                                    padding:40px;
                                "
                            >

                                📋

                                <br>

                                Belum ada data peminjaman.

                            </td>

                        </tr>


                        <?php

                        endif;

                        ?>


                        </tbody>


                    </table>


                </div>


            </div>



            <!-- =========================
                 MENU CEPAT
            ========================= -->

            <div class="panel">


                <div class="panel-header">

                    <h3>
                        ⚡ Menu Cepat
                    </h3>

                </div>


                <div class="quick-menu">


                    <!-- TAMBAH ANGGOTA -->

                    <a
                        href="anggota/tambah.php"
                        class="quick"
                    >

                        <div class="quick-icon">
                            👤
                        </div>

                        <span>
                            Tambah Anggota
                        </span>

                    </a>



                    <!-- TAMBAH ALAT -->

                    <a
                        href="alat/tambah.php"
                        class="quick"
                    >

                        <div class="quick-icon">
                            📦
                        </div>

                        <span>
                            Tambah Alat
                        </span>

                    </a>



                    <!-- PEMINJAMAN -->

                    <a
                        href="peminjaman/tambah.php"
                        class="quick"
                    >

                        <div class="quick-icon">
                            📋
                        </div>

                        <span>
                            Peminjaman
                        </span>

                    </a>



                    <!-- PENGEMBALIAN -->

                    <a
                        href="pengembalian/index.php"
                        class="quick"
                    >

                        <div class="quick-icon">
                            🔄
                        </div>

                        <span>
                            Pengembalian
                        </span>

                    </a>



                    <!-- LAPORAN -->

                    <a
                        href="laporan/peminjaman.php"
                        class="quick"
                    >

                        <div class="quick-icon">
                            📊
                        </div>

                        <span>
                            Laporan
                        </span>

                    </a>


                </div>


            </div>


        </div>



        <!-- =========================
             INFORMASI KARANG TARUNA MANUNGGAL BHAKTI
        ========================= -->

        <div class="info-section">


            <div class="info-section-title">

                <h3>
                    Informasi Karang Taruna Manunggal Bhakti
                </h3>

                <p>
                    Informasi umum, visi, misi,
                    dan ketentuan penggunaan alat.
                </p>

            </div>



            <div class="info-cards">


                <!-- TENTANG KARANG TARUNA  MANUNGGAL BHAKTI-->

                <div class="info-card">

                    <div class="info-card-header">

                        <div class="info-card-icon">
                            🏘️
                        </div>

                        <h4>
                            Tentang Karang Taruna Manunggal Bhakti
                        </h4>

                    </div>


                    <p>
                        Karang Taruna Manunggal Bhakti merupakan organisasi
                        kepemudaan yang menjadi wadah bagi
                        generasi muda untuk mengembangkan
                        kreativitas, kepedulian sosial,
                        serta berpartisipasi dalam berbagai
                        kegiatan di lingkungan masyarakat.
                    </p>

                </div>



                <!-- VISI -->

                <div class="info-card visi">

                    <div class="info-card-header">

                        <div class="info-card-icon">
                            🎯
                        </div>

                        <h4>
                            Visi
                        </h4>

                    </div>


                    <p>
                        Membangun generasi muda yang aktif,
                        kreatif, berakhlak mulia, dan peduli
                        terhadap kesejahteraan sosial
                        masyarakat.
                    </p>

                </div>



                <!-- MISI -->

                <div class="info-card misi">

                    <div class="info-card-header">

                        <div class="info-card-icon">
                            📌
                        </div>

                        <h4>
                            Misi
                        </h4>

                    </div>


                    <ol>

                        <li>
                            Mengadakan kegiatan positif
                            kepemudaan secara rutin.
                        </li>

                        <li>
                            Mempererat kerukunan antarwarga
                            dan pemuda.
                        </li>

                        <li>
                            Berpartisipasi aktif dalam
                            kegiatan sosial dan peringatan
                            hari besar nasional, seperti HUT RI.
                        </li>

                    </ol>

                </div>



                <!-- KETENTUAN PEMINJAMAN -->

                <div class="info-card ketentuan">

                    <div class="info-card-header">

                        <div class="info-card-icon">
                            📋
                        </div>

                        <h4>
                            Ketentuan Peminjaman Alat
                        </h4>

                    </div>


                    <ol>

                        <li>
                            Peminjaman dilakukan melalui
                            sistem yang telah disediakan.
                        </li>

                        <li>
                            Peminjam wajib mengisi data
                            dengan benar.
                        </li>

                        <li>
                            Alat yang dipinjam harus digunakan
                            dengan baik dan bertanggung jawab.
                        </li>

                        <li>
                            Alat wajib dikembalikan sesuai
                            tanggal yang telah ditentukan.
                        </li>

                        <li>
                            Kerusakan atau kehilangan alat
                            menjadi tanggung jawab peminjam
                            sesuai ketentuan yang berlaku.
                        </li>

                    </ol>

                </div>

        <!-- =========================
             INFO SISTEM
        ========================= -->

        <div class="info-box">
            <strong style="color:#334155;">Informasi Sistem:</strong>
            Status pengajuan dapat dipantau melalui menu Status Peminjaman.
            Pengajuan berstatus Menunggu perlu diperiksa oleh Admin.
        </div>


    </section>


</main>


</body>

</html>